import { addDays, format, parseISO, startOfWeek } from 'date-fns'

/** Local calendar date as yyyy-MM-dd. */
export const toIso = (d: Date) => format(d, 'yyyy-MM-dd')
export const todayIso = () => toIso(new Date())
export const fromIso = (s: string) => parseISO(s)
export const shiftIso = (s: string, days: number) => toIso(addDays(fromIso(s), days))

/** Weeks start on Monday. */
export const weekStartIso = (s: string) => toIso(startOfWeek(fromIso(s), { weekStartsOn: 1 }))

export function daysBetween(from: string, to: string): string[] {
  const out: string[] = []
  for (let d = from; d <= to; d = shiftIso(d, 1)) out.push(d)
  return out
}

export const prettyDay = (s: string) => format(fromIso(s), 'EEE, MMM d')
export const shortDay = (s: string) => format(fromIso(s), 'MMM d')
