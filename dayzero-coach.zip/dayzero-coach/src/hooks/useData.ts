import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { repo } from '../data'
import type { DailyMetricPatch } from '../data/repository'
import type { FoodInput, NewClient, NewFoodEntry, TargetsInput } from '../schemas'

export const keys = {
  myClient: ['myClient'] as const,
  clients: ['clients'] as const,
  client: (id: string) => ['client', id] as const,
  targets: (id: string) => ['targets', id] as const,
  food: (id: string, from: string, to: string) => ['food', id, from, to] as const,
  foodAll: (id: string) => ['food', id] as const,
  saved: (id: string) => ['saved', id] as const,
  metrics: (id: string, from: string, to: string) => ['metrics', id, from, to] as const,
  metricsAll: (id: string) => ['metrics', id] as const,
}

export const useMyClient = () => useQuery({ queryKey: keys.myClient, queryFn: () => repo.getMyClient() })
export const useClients = () => useQuery({ queryKey: keys.clients, queryFn: () => repo.listClients() })
export const useClient = (id: string) => useQuery({ queryKey: keys.client(id), queryFn: () => repo.getClient(id) })
export const useTargets = (id: string | undefined) =>
  useQuery({ queryKey: keys.targets(id ?? ''), queryFn: () => repo.listTargets(id!), enabled: !!id })
export const useFood = (id: string | undefined, from: string, to: string) =>
  useQuery({ queryKey: keys.food(id ?? '', from, to), queryFn: () => repo.listFoodEntries(id!, from, to), enabled: !!id })
export const useSavedFoods = (id: string | undefined) =>
  useQuery({ queryKey: keys.saved(id ?? ''), queryFn: () => repo.listSavedFoods(id!), enabled: !!id })
export const useMetrics = (id: string | undefined, from: string, to: string) =>
  useQuery({
    queryKey: keys.metrics(id ?? '', from, to),
    queryFn: () => repo.listDailyMetrics(id!, from, to),
    enabled: !!id,
  })

export function useAddFood(clientId: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (e: NewFoodEntry) => repo.addFoodEntry(e),
    onSuccess: () => qc.invalidateQueries({ queryKey: keys.foodAll(clientId) }),
  })
}

export function useDeleteFood(clientId: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => repo.deleteFoodEntry(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: keys.foodAll(clientId) }),
  })
}

export function useSaveFood(clientId: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (f: FoodInput) => repo.saveFood(clientId, f),
    onSuccess: () => qc.invalidateQueries({ queryKey: keys.saved(clientId) }),
  })
}

export function useDeleteSavedFood(clientId: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => repo.deleteSavedFood(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: keys.saved(clientId) }),
  })
}

export function useUpsertMetric(clientId: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ date, patch }: { date: string; patch: DailyMetricPatch }) =>
      repo.upsertDailyMetric(clientId, date, patch),
    onSuccess: () => qc.invalidateQueries({ queryKey: keys.metricsAll(clientId) }),
  })
}

export function useCreateClient() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ client, targets }: { client: NewClient; targets: TargetsInput }) =>
      repo.createClient(client, targets),
    onSuccess: () => qc.invalidateQueries({ queryKey: keys.clients }),
  })
}

export function useUpdateClient(id: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (patch: Partial<NewClient>) => repo.updateClient(id, patch),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: keys.clients })
      qc.invalidateQueries({ queryKey: keys.client(id) })
    },
  })
}

export function useSetTargets(clientId: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ targets, effectiveFrom }: { targets: TargetsInput; effectiveFrom: string }) =>
      repo.setTargets(clientId, targets, effectiveFrom),
    onSuccess: () => qc.invalidateQueries({ queryKey: keys.targets(clientId) }),
  })
}
