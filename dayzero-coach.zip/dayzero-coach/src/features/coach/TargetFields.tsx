import { Field } from '../../components/ui'
import { caloriesFromMacros } from '../../lib/nutrition'
import type { TargetsInput } from '../../schemas'

export type TargetForm = Record<'calories' | 'proteinG' | 'carbsG' | 'fatG' | 'dailySteps' | 'goalWeightLbs', string>

export const targetsToForm = (t: TargetsInput): TargetForm => ({
  calories: String(t.calories),
  proteinG: String(t.proteinG),
  carbsG: String(t.carbsG),
  fatG: String(t.fatG),
  dailySteps: String(t.dailySteps),
  goalWeightLbs: t.goalWeightLbs === null ? '' : String(t.goalWeightLbs),
})

const num = (s: string) => (s.trim() === '' ? NaN : Number(s))

export const parseTargetForm = (f: TargetForm) => ({
  calories: num(f.calories),
  proteinG: num(f.proteinG),
  carbsG: num(f.carbsG),
  fatG: num(f.fatG),
  dailySteps: num(f.dailySteps),
  goalWeightLbs: f.goalWeightLbs.trim() === '' ? null : num(f.goalWeightLbs),
})

export function TargetFields({
  value,
  onChange,
  errors = {},
}: {
  value: TargetForm
  onChange: (v: TargetForm) => void
  errors?: Record<string, string>
}) {
  const set = (k: keyof TargetForm) => (e: { target: { value: string } }) => onChange({ ...value, [k]: e.target.value })
  const macroCals = caloriesFromMacros(Number(value.proteinG) || 0, Number(value.carbsG) || 0, Number(value.fatG) || 0)
  const cals = Number(value.calories) || 0
  const off = cals > 0 && Math.abs(macroCals - cals) > 75
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Field label="Calories" type="number" inputMode="numeric" value={value.calories} onChange={set('calories')} error={errors['t.calories']} />
        <Field label="Protein g" type="number" inputMode="numeric" value={value.proteinG} onChange={set('proteinG')} error={errors['t.proteinG']} />
        <Field label="Carbs g" type="number" inputMode="numeric" value={value.carbsG} onChange={set('carbsG')} error={errors['t.carbsG']} />
        <Field label="Fat g" type="number" inputMode="numeric" value={value.fatG} onChange={set('fatG')} error={errors['t.fatG']} />
        <Field label="Daily steps" type="number" inputMode="numeric" value={value.dailySteps} onChange={set('dailySteps')} error={errors['t.dailySteps']} />
        <Field label="Goal weight (lbs)" type="number" inputMode="decimal" value={value.goalWeightLbs} onChange={set('goalWeightLbs')} />
      </div>
      <p className={`text-sm ${off ? 'text-warn' : 'text-muted'}`}>
        Macros add up to {macroCals.toLocaleString()} calories
        {off ? `, ${Math.abs(macroCals - cals).toLocaleString()} off the calorie target.` : '.'}
      </p>
    </div>
  )
}
