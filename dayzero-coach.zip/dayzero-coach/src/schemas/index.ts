import { z } from 'zod'

/** Calendar dates are stored as local "yyyy-MM-dd" strings everywhere. */
export const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Expected yyyy-MM-dd')

export const LEAD_SOURCES = ['referral', 'social', 'gym', 'email_list'] as const
export const STAGES = ['lead', 'consult', 'beta', 'active', 'paused', 'churned'] as const
export const TIERS = ['beta', 'tier_1', 'tier_2', 'tier_3'] as const
export const GOALS = ['fat_loss', 'muscle_gain', 'recomp', 'maintenance'] as const
export const MEALS = ['breakfast', 'lunch', 'dinner', 'snack'] as const

export const LeadSource = z.enum(LEAD_SOURCES)
export const Stage = z.enum(STAGES)
export const Tier = z.enum(TIERS)
export const Goal = z.enum(GOALS)
export const Meal = z.enum(MEALS)

const nonNeg = z.number().finite().nonnegative()

export const ClientSchema = z.object({
  id: z.string(),
  profileId: z.string().nullable(),
  name: z.string().min(1, 'Name is required'),
  email: z.string().email('Enter a valid email'),
  leadSource: LeadSource,
  stage: Stage,
  programTier: Tier,
  goal: Goal,
  startDate: isoDate.nullable(),
  nextCheckInDate: isoDate.nullable(),
  notes: z.string(),
  createdAt: z.string(),
})

export const NewClientSchema = ClientSchema.omit({ id: true, profileId: true, createdAt: true })

export const TargetsInputSchema = z.object({
  calories: nonNeg,
  proteinG: nonNeg,
  carbsG: nonNeg,
  fatG: nonNeg,
  dailySteps: nonNeg,
  goalWeightLbs: nonNeg.nullable(),
})

export const ClientTargetsSchema = TargetsInputSchema.extend({
  id: z.string(),
  clientId: z.string(),
  effectiveFrom: isoDate,
})

export const FoodInputSchema = z.object({
  name: z.string().trim().min(1, 'Name the food'),
  calories: nonNeg,
  proteinG: nonNeg,
  carbsG: nonNeg,
  fatG: nonNeg,
})

export const NewFoodEntrySchema = FoodInputSchema.extend({
  clientId: z.string(),
  date: isoDate,
  meal: Meal,
  servings: z.number().positive('Servings must be more than 0'),
})

export const FoodEntrySchema = NewFoodEntrySchema.extend({
  id: z.string(),
  createdAt: z.string(),
})

export const SavedFoodSchema = FoodInputSchema.extend({
  id: z.string(),
  clientId: z.string(),
})

export const DailyMetricSchema = z.object({
  id: z.string(),
  clientId: z.string(),
  date: isoDate,
  weightLbs: nonNeg.nullable(),
  steps: z.number().int().nonnegative().nullable(),
  note: z.string().nullable(),
})

export type LeadSource = z.infer<typeof LeadSource>
export type Stage = z.infer<typeof Stage>
export type Tier = z.infer<typeof Tier>
export type Goal = z.infer<typeof Goal>
export type Meal = z.infer<typeof Meal>
export type Client = z.infer<typeof ClientSchema>
export type NewClient = z.infer<typeof NewClientSchema>
export type TargetsInput = z.infer<typeof TargetsInputSchema>
export type ClientTargets = z.infer<typeof ClientTargetsSchema>
export type FoodInput = z.infer<typeof FoodInputSchema>
export type NewFoodEntry = z.infer<typeof NewFoodEntrySchema>
export type FoodEntry = z.infer<typeof FoodEntrySchema>
export type SavedFood = z.infer<typeof SavedFoodSchema>
export type DailyMetric = z.infer<typeof DailyMetricSchema>

export const LABELS = {
  leadSource: { referral: 'Referral', social: 'Social', gym: 'Gym', email_list: 'Email list' },
  stage: {
    lead: 'Lead',
    consult: 'Consult',
    beta: 'Beta',
    active: 'Active',
    paused: 'Paused',
    churned: 'Churned',
  },
  tier: { beta: 'Beta', tier_1: 'Tier 1', tier_2: 'Tier 2', tier_3: 'Tier 3' },
  goal: {
    fat_loss: 'Fat loss',
    muscle_gain: 'Muscle gain',
    recomp: 'Recomp',
    maintenance: 'Maintenance',
  },
  meal: { breakfast: 'Breakfast', lunch: 'Lunch', dinner: 'Dinner', snack: 'Snacks' },
} as const
