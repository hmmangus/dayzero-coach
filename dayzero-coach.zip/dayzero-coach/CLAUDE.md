# Dayzero Coach

Client nutrition/progress tracker for a fitness coaching business. Clients log food, macros, weight, steps; the coach sees weekly averages. See README.md for setup and architecture.

## Stack
React + Vite + TypeScript (strict), Tailwind v4, React Router, TanStack Query, Zod, Recharts, date-fns, Supabase (Postgres + magic-link auth + RLS), Vitest + Testing Library.

## Rules
- UI never touches Supabase or localStorage directly. Add a method to `src/data/repository.ts`, implement it in BOTH `supabaseRepository.ts` and `demoRepository.ts`, expose it via a hook in `src/hooks/useData.ts`.
- Data shapes live in `src/schemas/index.ts` (Zod). Types are inferred from schemas.
- Calculations go in `src/lib/` as pure functions with tests. Never compute averages in components.
- Dates are local `yyyy-MM-dd` strings. Weeks start Monday. Use helpers in `src/lib/dates.ts`.
- Weekly averages skip unlogged days and leave today (in progress) out. Keep that behavior.
- Access control is enforced by RLS in `supabase/migrations/`. Schema changes go in a NEW migration file; never edit an applied one.
- Never commit `.env` or real client data. Seed data must be clearly fake.

## Commands
- `npm run dev` (demo mode when no .env)
- `npm test`
- `npm run build` (runs `tsc -b` first)

## Design
Colors and fonts are tokens in `src/index.css` (`@theme`). Cobalt = calories, rose = protein, amber = carbs, teal = fat. Bricolage Grotesque (`.num`, headings) + Figtree (UI). Mobile-first for client screens; coach screens are table-first.
