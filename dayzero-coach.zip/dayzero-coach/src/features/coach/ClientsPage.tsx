import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { Button, ErrorNote, fmt, Spinner } from '../../components/ui'
import { useClients } from '../../hooks/useData'
import { shortDay } from '../../lib/dates'
import { LABELS, type Client, type Stage } from '../../schemas'
import { useRosterStats, type ClientRowStats } from './clientStats'
import { NewClientSheet } from './NewClientSheet'

type Group = 'coaching' | 'pipeline' | 'inactive' | 'all'
const GROUPS: { id: Group; label: string; stages: Stage[] }[] = [
  { id: 'coaching', label: 'Coaching', stages: ['active', 'beta'] },
  { id: 'pipeline', label: 'Pipeline', stages: ['lead', 'consult'] },
  { id: 'inactive', label: 'Paused & churned', stages: ['paused', 'churned'] },
  { id: 'all', label: 'All', stages: ['lead', 'consult', 'beta', 'active', 'paused', 'churned'] },
]

export function ClientsPage() {
  const clients = useClients()
  const [group, setGroup] = useState<Group>('coaching')
  const [q, setQ] = useState('')
  const [adding, setAdding] = useState(false)
  const stats = useRosterStats(clients.data ?? [])

  const visible = useMemo(() => {
    const stages = GROUPS.find((g) => g.id === group)!.stages
    return (clients.data ?? [])
      .filter((c) => stages.includes(c.stage))
      .filter((c) => !q || `${c.name} ${c.email}`.toLowerCase().includes(q.toLowerCase()))
      .sort((a, b) => {
        // Clients who need a nudge float to the top.
        const na = stats.get(a.id)?.needsAttention ? 0 : 1
        const nb = stats.get(b.id)?.needsAttention ? 0 : 1
        return na - nb || a.name.localeCompare(b.name)
      })
  }, [clients.data, group, q, stats])

  if (clients.isLoading) return <Spinner />
  if (clients.error) return <ErrorNote error={clients.error} />

  const coaching = (clients.data ?? []).filter((c) => c.stage === 'active' || c.stage === 'beta')
  const attention = coaching.filter((c) => stats.get(c.id)?.needsAttention)

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="num text-4xl font-extrabold tracking-tight">Clients</h1>
          <p className="mt-1 text-muted">
            {coaching.length} coaching now
            {attention.length > 0 && (
              <>
                , <b className="text-warn">{attention.length} haven't logged in 3+ days</b>
              </>
            )}
            .
          </p>
        </div>
        <Button onClick={() => setAdding(true)}>Add client</Button>
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-2">
        {GROUPS.map((g) => (
          <button
            key={g.id}
            onClick={() => setGroup(g.id)}
            aria-pressed={group === g.id}
            className={`rounded-full px-4 py-2 text-sm font-semibold ${group === g.id ? 'bg-ink text-white' : 'bg-surface text-muted hover:text-ink'}`}
          >
            {g.label}
          </button>
        ))}
        <input
          type="search"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search by name or email"
          aria-label="Search clients"
          className="ml-auto h-10 w-full rounded-full border border-line bg-surface px-4 text-[15px] outline-none focus:border-cobalt sm:w-64"
        />
      </div>

      {visible.length === 0 ? (
        <div className="mt-10 rounded-3xl border border-dashed border-line px-6 py-14 text-center">
          <p className="font-semibold">{q ? 'No clients match that search.' : 'No clients in this group yet.'}</p>
          {!q && (
            <Button variant="secondary" className="mt-4" onClick={() => setAdding(true)}>
              Add a client
            </Button>
          )}
        </div>
      ) : (
        <div className="mt-4 overflow-x-auto rounded-3xl bg-surface">
          <table className="w-full min-w-[760px] text-left text-[15px]">
            <thead className="border-b border-line text-sm text-muted">
              <tr>
                <th className="px-5 py-3 font-medium">Client</th>
                <th className="px-3 py-3 font-medium">Stage</th>
                <th className="px-3 py-3 font-medium">Days logged</th>
                <th className="px-3 py-3 font-medium">Avg calories</th>
                <th className="px-3 py-3 font-medium">Avg protein</th>
                <th className="px-3 py-3 font-medium">Weight vs last week</th>
                <th className="px-5 py-3 font-medium">Last log</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {visible.map((c) => (
                <Row key={c.id} client={c} s={stats.get(c.id)} />
              ))}
            </tbody>
          </table>
        </div>
      )}

      {adding && <NewClientSheet onClose={() => setAdding(false)} />}
    </div>
  )
}

function Row({ client: c, s }: { client: Client; s: ClientRowStats | undefined }) {
  const w = s?.thisWeek
  const t = w?.target
  const calDiff = w?.avgCalories != null && t ? (w.avgCalories - t.calories) / t.calories : null
  return (
    <tr className="hover:bg-paper/60">
      <td className="px-5 py-3">
        <Link to={`/clients/${c.id}`} className="font-semibold hover:text-cobalt">
          {c.name}
        </Link>
        <p className="text-sm text-muted">{LABELS.tier[c.programTier]}, {LABELS.goal[c.goal].toLowerCase()}</p>
      </td>
      <td className="px-3 py-3">{LABELS.stage[c.stage]}</td>
      <td className="px-3 py-3">
        {s?.loading ? '…' : w ? <span className="num font-semibold">{w.daysLogged} / {w.days.filter((d) => !d.inProgress).length}</span> : '—'}
      </td>
      <td className="px-3 py-3">
        <span className="num font-semibold">{fmt(w?.avgCalories)}</span>
        {calDiff !== null && (
          <span className={`ml-1.5 text-sm ${Math.abs(calDiff) <= 0.1 ? 'text-good' : 'text-warn'}`}>
            {calDiff > 0 ? '+' : ''}
            {Math.round(calDiff * 100)}%
          </span>
        )}
      </td>
      <td className="px-3 py-3">
        <span className="num font-semibold">{w?.avgProteinG != null ? `${fmt(w.avgProteinG)}g` : '—'}</span>
        {t && w?.avgProteinG != null && <span className="ml-1 text-sm text-muted">/ {fmt(t.proteinG)}</span>}
      </td>
      <td className="px-3 py-3 num font-semibold">
        {w?.weightChangeLbs != null ? `${w.weightChangeLbs > 0 ? '+' : ''}${fmt(w.weightChangeLbs, 1)} lbs` : '—'}
      </td>
      <td className="px-5 py-3">
        {s?.needsAttention ? (
          <span className="font-semibold text-warn">{s.lastLogged ? `${s.daysSinceLog} days ago` : 'Not in 2 weeks'}</span>
        ) : s?.lastLogged ? (
          s.daysSinceLog === 0 ? 'Today' : s.daysSinceLog === 1 ? 'Yesterday' : shortDay(s.lastLogged)
        ) : (
          <span className="text-muted">—</span>
        )}
      </td>
    </tr>
  )
}
