# Dayzero Coach

A nutrition and progress tracker for a small fitness coaching business. Clients log food, macros, weight, and steps from their phones (Cal AI–style, manual entry). The coach sees each client's daily logs rolled up into **weekly averages** against their targets.

Built for Dayzerotraining, a coaching business I run.

| Client: today | Client: week | Coach: roster | Coach: client detail |
| --- | --- | --- | --- |
| ![](docs/screenshots/client-today.png) | ![](docs/screenshots/client-week.png) | ![](docs/screenshots/coach-roster.png) | ![](docs/screenshots/coach-client.png) |

## Why it exists

Coaching check-ins used to mean screenshots from three different apps and a lot of mental math. Daily numbers are noisy (water weight, one big dinner), so what matters is the weekly trend, and an honest one: a client who logs two perfect days shouldn't look like they had a perfect week. This app makes logging fast for clients and gives the coach one table that answers "how did this week actually go?"

## Features

**Client app** (mobile-first, installable to the home screen)
- Today screen: calories-left ring, protein/carbs/fat progress, steps and weight tiles
- Log food by meal with calories, macros, and servings
- Fills in calories from macros (4/4/9) when left blank, and flags entries where the two disagree
- My foods (saved favorites) and Recent foods for one-tap re-logging
- Week view: day-by-day on-target strip, weekly averages, daily calorie chart
- Logging streak

**Coach dashboard**
- Roster with this week's days logged, average calories vs target, protein, and weight change
- Clients who haven't logged in 3+ days float to the top
- Client detail: weekly averages table (4/8/12 weeks), drill into any week to see every food
- Charts: weight with 7-day average and goal line, weekly calories vs target, macro split, steps
- Versioned targets: change a client's targets without rewriting how past weeks are judged
- Stage, program tier, check-in date, and notes per client

## Running it locally

Requires Node 20+.

```bash
npm install
npm run dev        # http://localhost:5173
npm test           # unit + component tests
npm run build      # type-check and production build
```

With no `.env` file, the app runs in **demo mode**: 8 fake clients with 4–12 weeks of generated logs, stored in your browser. Use the buttons on the sign-in screen to open the coach dashboard or the client app.

## Setting it up for real clients (Supabase)

Supabase provides the database, sign-in, and access rules. The free tier is enough for a small coaching business.

1. **Create a project** at [supabase.com](https://supabase.com). Pick a region near you and save the database password somewhere safe.
2. **Create the tables.** In the Supabase dashboard, open **SQL Editor → New query**, paste all of `supabase/migrations/20261107000000_init.sql`, and click **Run**.
3. *(Optional)* To try the coach view with fake data, run `supabase/seed.sql` the same way. Delete it before adding real clients:
   ```sql
   delete from public.clients where email like '%@example.com';
   ```
4. **Connect the app.** Go to **Project Settings → API**. Copy `.env.example` to `.env` and fill in:
   ```
   VITE_SUPABASE_URL=<Project URL>
   VITE_SUPABASE_ANON_KEY=<anon public key>
   ```
   The anon key is meant to be public; the database's row-level security is what protects the data. Never put the `service_role` key in this app.
5. **Allow sign-in links.** Go to **Authentication → URL Configuration**. Set **Site URL** to where the app lives (your Vercel URL, or `http://localhost:5173` while testing) and add both to **Redirect URLs**.
6. **Make yourself the coach.** Run `npm run dev`, sign in with your email, and click the link in your inbox. Then in the SQL Editor run:
   ```sql
   update public.profiles set role = 'coach' where email = 'you@yourdomain.com';
   ```
   Refresh the app and you'll see the coach dashboard.
7. **Add clients.** Click **Add client**, enter their name, email, and targets. Send them the app link and tell them to sign in with that exact email. Their account links to their client record automatically.

### Before you have more than a few clients

Supabase's built-in email sender has a low hourly limit and is meant for testing. Once clients are signing in regularly, set up a custom SMTP provider (for example Resend or Postmark) under **Authentication → Emails → SMTP Settings**.

### Deploying (Vercel)

1. Push this repo to GitHub.
2. In [Vercel](https://vercel.com), **Add New → Project**, import the repo. It detects Vite automatically.
3. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` under **Environment Variables**, then deploy.
4. Put the Vercel URL into Supabase's **Site URL** and **Redirect URLs** (step 5 above).

For a public portfolio demo, deploy a second Vercel project with no environment variables. It runs in demo mode with only fake data.

## Architecture

```
src/
  schemas/         Zod schemas: the single source of truth for data shapes and types
  data/            Repository interface + two implementations
    repository.ts        what the UI is allowed to ask for
    supabaseRepository.ts real backend; maps snake_case rows to app types
    demoRepository.ts    localStorage backend for demos and local dev
    demoSeed.ts          deterministic fake clients and logs
  lib/             Pure functions, no React: dates, nutrition math, weekly rollups
  hooks/useData.ts TanStack Query hooks (caching, invalidation after writes)
  auth/            Signed-in viewer and their role
  components/      Shared UI: ring, macro bars, sheets, week detail
  features/
    auth/          Sign-in
    client/        Today, Week, Log food, Log weight/steps
    coach/         Roster, client detail, charts, targets
supabase/
  migrations/      Schema, triggers, row-level security
  seed.sql         Optional sample data
```

### Data model

```mermaid
erDiagram
  profiles ||--o| clients : "signs in as"
  clients ||--o{ client_targets : "has versions"
  clients ||--o{ food_entries : logs
  clients ||--o{ saved_foods : saves
  clients ||--o{ daily_metrics : logs

  profiles { uuid id PK  text email  text role "coach | client" }
  clients { uuid id PK  uuid profile_id FK  text name  text email  text stage  text program_tier  text goal  date start_date  date next_check_in_date }
  client_targets { uuid id PK  uuid client_id FK  date effective_from  numeric calories  numeric protein_g  numeric carbs_g  numeric fat_g  int daily_steps  numeric goal_weight_lbs }
  food_entries { uuid id PK  uuid client_id FK  date date  text meal  text name  numeric calories  numeric protein_g  numeric carbs_g  numeric fat_g  numeric servings }
  saved_foods { uuid id PK  uuid client_id FK  text name  numeric calories }
  daily_metrics { uuid id PK  uuid client_id FK  date date  numeric weight_lbs  int steps }
```

### Who can see what (row-level security)

Access is enforced in the database, not the UI, so a client can't see another client's data even by calling the API directly.

- A new sign-in gets a `profiles` row with role `client`. Nobody can change their own role; only SQL run by the project owner can make someone a coach.
- When a profile's email matches a `clients.email`, a trigger links them (whether the client or the coach acts first).
- **Coach:** full access to every table.
- **Client:** can read their own client record and targets, and read/write only their own food, saved foods, and weight/steps.

These rules are tested against Postgres: clients see only their own rows, can't write to another client, can't edit their targets, and can't promote themselves.

### How weekly averages work

All of this lives in `src/lib/weekly.ts` as pure functions with tests in `weekly.test.ts`.

- **Weeks run Monday to Sunday.**
- **Averages use logged days only.** A day with no food entries isn't counted as zero calories, because that would make a client who forgot to log look like they were starving. Every average is shown next to "days logged" so a strong average from two days is visibly thin.
- **Today is "in progress."** It's shown on the client's screen but left out of averages and adherence until it ends; half a day of food would otherwise read as a huge deficit. The morning weigh-in still counts.
- **Weight uses weekly averages** for week-over-week change, which smooths out daily water-weight swings. Charts also show a 7-day moving average.
- **Adherence:** a day is on calorie target within ±10%, on protein target at 90% or more, on steps at or above the goal.
- **Targets are versioned.** Each day is judged against the target in effect on that date, so changing a client's calories in week 6 doesn't rewrite weeks 1–5.

### Why a repository layer

The UI only talks to the `Repository` interface. That made demo mode free (the same screens run on localStorage), keeps Supabase details in one file, and means swapping the backend later touches one class rather than every component.

## Tradeoffs

- **Manual entry, no food database yet.** Fastest path to clients actually logging. Saved and recent foods cover most repeat meals.
- **Magic-link sign-in, no passwords.** Less friction for clients and nothing to reset. The cost is relying on email delivery (see SMTP note).
- **One coach role.** Fine for one or two coaches sharing a client list. Multiple independent coaches would need a `coach_id` on clients and narrower policies.

## Roadmap

- AI photo meal logging and barcode scanning, with USDA FoodData Central search
- Apple Health / Google Fit step sync
- Pipeline kanban (lead → consult → beta → active) and lead-source conversion metrics
- Weekly check-in form with adherence rating and coach notes
- Push reminders when a client hasn't logged by evening
