import { createClient as createSupabase, type SupabaseClient } from '@supabase/supabase-js'
import {
  ClientSchema,
  ClientTargetsSchema,
  DailyMetricSchema,
  FoodEntrySchema,
  SavedFoodSchema,
  type Client,
  type ClientTargets,
  type DailyMetric,
  type FoodEntry,
  type FoodInput,
  type NewClient,
  type NewFoodEntry,
  type SavedFood,
  type TargetsInput,
} from '../schemas'
import type { DailyMetricPatch, Repository, Role, Viewer } from './repository'

type Row = Record<string, unknown>

const num = (v: unknown) => (v === null || v === undefined ? null : Number(v))

// ---- row <-> domain mapping (DB is snake_case, app is camelCase) ----

const toClient = (r: Row): Client =>
  ClientSchema.parse({
    id: r.id,
    profileId: r.profile_id ?? null,
    name: r.name,
    email: r.email,
    leadSource: r.lead_source,
    stage: r.stage,
    programTier: r.program_tier,
    goal: r.goal,
    startDate: r.start_date ?? null,
    nextCheckInDate: r.next_check_in_date ?? null,
    notes: r.notes ?? '',
    createdAt: r.created_at,
  })

const fromClient = (c: Partial<NewClient>): Row => {
  const out: Row = {}
  if (c.name !== undefined) out.name = c.name
  if (c.email !== undefined) out.email = c.email.toLowerCase()
  if (c.leadSource !== undefined) out.lead_source = c.leadSource
  if (c.stage !== undefined) out.stage = c.stage
  if (c.programTier !== undefined) out.program_tier = c.programTier
  if (c.goal !== undefined) out.goal = c.goal
  if (c.startDate !== undefined) out.start_date = c.startDate
  if (c.nextCheckInDate !== undefined) out.next_check_in_date = c.nextCheckInDate
  if (c.notes !== undefined) out.notes = c.notes
  return out
}

const toTargets = (r: Row): ClientTargets =>
  ClientTargetsSchema.parse({
    id: r.id,
    clientId: r.client_id,
    calories: num(r.calories),
    proteinG: num(r.protein_g),
    carbsG: num(r.carbs_g),
    fatG: num(r.fat_g),
    dailySteps: num(r.daily_steps),
    goalWeightLbs: num(r.goal_weight_lbs),
    effectiveFrom: r.effective_from,
  })

const toFood = (r: Row): FoodEntry =>
  FoodEntrySchema.parse({
    id: r.id,
    clientId: r.client_id,
    date: r.date,
    meal: r.meal,
    name: r.name,
    calories: num(r.calories),
    proteinG: num(r.protein_g),
    carbsG: num(r.carbs_g),
    fatG: num(r.fat_g),
    servings: num(r.servings),
    createdAt: r.created_at,
  })

const toSaved = (r: Row): SavedFood =>
  SavedFoodSchema.parse({
    id: r.id,
    clientId: r.client_id,
    name: r.name,
    calories: num(r.calories),
    proteinG: num(r.protein_g),
    carbsG: num(r.carbs_g),
    fatG: num(r.fat_g),
  })

const toMetric = (r: Row): DailyMetric =>
  DailyMetricSchema.parse({
    id: r.id,
    clientId: r.client_id,
    date: r.date,
    weightLbs: num(r.weight_lbs),
    steps: num(r.steps),
    note: r.note ?? null,
  })

function check<T>(res: { data: T; error: { message: string } | null }): NonNullable<T> {
  if (res.error) throw new Error(res.error.message)
  if (res.data === null || res.data === undefined) throw new Error('No data returned')
  return res.data as NonNullable<T>
}

export class SupabaseRepository implements Repository {
  readonly mode = 'supabase' as const
  private sb: SupabaseClient

  constructor(url: string, anonKey: string) {
    this.sb = createSupabase(url, anonKey)
  }

  async getViewer(): Promise<Viewer | null> {
    const { data } = await this.sb.auth.getUser()
    const user = data.user
    if (!user) return null
    const profile = await this.sb.from('profiles').select('role').eq('id', user.id).maybeSingle()
    const role = (profile.data?.role as Role | undefined) ?? 'client'
    return { userId: user.id, email: user.email ?? '', role }
  }

  async signIn(email: string) {
    const { error } = await this.sb.auth.signInWithOtp({
      email: email.trim().toLowerCase(),
      options: { emailRedirectTo: window.location.origin },
    })
    if (error) throw new Error(error.message)
    return { message: `Check ${email} for a sign-in link.` }
  }

  async signOut() {
    await this.sb.auth.signOut()
  }

  onAuthChange(cb: () => void) {
    const { data } = this.sb.auth.onAuthStateChange(() => cb())
    return () => data.subscription.unsubscribe()
  }

  async getMyClient() {
    const { data: auth } = await this.sb.auth.getUser()
    if (!auth.user) return null
    const res = await this.sb.from('clients').select('*').eq('profile_id', auth.user.id).maybeSingle()
    if (res.error) throw new Error(res.error.message)
    return res.data ? toClient(res.data) : null
  }

  async listClients() {
    return check(await this.sb.from('clients').select('*').order('name')).map(toClient)
  }

  async getClient(id: string) {
    const res = await this.sb.from('clients').select('*').eq('id', id).maybeSingle()
    if (res.error) throw new Error(res.error.message)
    return res.data ? toClient(res.data) : null
  }

  async createClient(input: NewClient, targets: TargetsInput) {
    const row = check(await this.sb.from('clients').insert(fromClient(input)).select().single())
    const client = toClient(row)
    await this.setTargets(client.id, targets, input.startDate ?? new Date().toISOString().slice(0, 10))
    return client
  }

  async updateClient(id: string, patch: Partial<NewClient>) {
    return toClient(check(await this.sb.from('clients').update(fromClient(patch)).eq('id', id).select().single()))
  }

  async listTargets(clientId: string) {
    return check(
      await this.sb.from('client_targets').select('*').eq('client_id', clientId).order('effective_from'),
    ).map(toTargets)
  }

  async setTargets(clientId: string, t: TargetsInput, effectiveFrom: string) {
    const row = check(
      await this.sb
        .from('client_targets')
        .upsert(
          {
            client_id: clientId,
            effective_from: effectiveFrom,
            calories: t.calories,
            protein_g: t.proteinG,
            carbs_g: t.carbsG,
            fat_g: t.fatG,
            daily_steps: t.dailySteps,
            goal_weight_lbs: t.goalWeightLbs,
          },
          { onConflict: 'client_id,effective_from' },
        )
        .select()
        .single(),
    )
    return toTargets(row)
  }

  async listFoodEntries(clientId: string, from: string, to: string) {
    return check(
      await this.sb
        .from('food_entries')
        .select('*')
        .eq('client_id', clientId)
        .gte('date', from)
        .lte('date', to)
        .order('created_at'),
    ).map(toFood)
  }

  async addFoodEntry(e: NewFoodEntry) {
    const row = check(
      await this.sb
        .from('food_entries')
        .insert({
          client_id: e.clientId,
          date: e.date,
          meal: e.meal,
          name: e.name,
          calories: e.calories,
          protein_g: e.proteinG,
          carbs_g: e.carbsG,
          fat_g: e.fatG,
          servings: e.servings,
        })
        .select()
        .single(),
    )
    return toFood(row)
  }

  async deleteFoodEntry(id: string) {
    const { error } = await this.sb.from('food_entries').delete().eq('id', id)
    if (error) throw new Error(error.message)
  }

  async listSavedFoods(clientId: string) {
    return check(await this.sb.from('saved_foods').select('*').eq('client_id', clientId).order('name')).map(toSaved)
  }

  async saveFood(clientId: string, f: FoodInput) {
    const row = check(
      await this.sb
        .from('saved_foods')
        .insert({
          client_id: clientId,
          name: f.name,
          calories: f.calories,
          protein_g: f.proteinG,
          carbs_g: f.carbsG,
          fat_g: f.fatG,
        })
        .select()
        .single(),
    )
    return toSaved(row)
  }

  async deleteSavedFood(id: string) {
    const { error } = await this.sb.from('saved_foods').delete().eq('id', id)
    if (error) throw new Error(error.message)
  }

  async listDailyMetrics(clientId: string, from: string, to: string) {
    return check(
      await this.sb
        .from('daily_metrics')
        .select('*')
        .eq('client_id', clientId)
        .gte('date', from)
        .lte('date', to)
        .order('date'),
    ).map(toMetric)
  }

  async upsertDailyMetric(clientId: string, date: string, patch: DailyMetricPatch) {
    const row: Row = { client_id: clientId, date }
    if (patch.weightLbs !== undefined) row.weight_lbs = patch.weightLbs
    if (patch.steps !== undefined) row.steps = patch.steps
    if (patch.note !== undefined) row.note = patch.note
    return toMetric(
      check(await this.sb.from('daily_metrics').upsert(row, { onConflict: 'client_id,date' }).select().single()),
    )
  }
}
