import { addDays, format, subWeeks, startOfWeek } from 'date-fns'
import type { Client, ClientTargets, DailyMetric, FoodEntry, SavedFood } from '../schemas'

/** Everything the demo repository stores. All people and numbers are fictional. */
export interface DemoDb {
  schemaVersion: 1
  clients: Client[]
  targets: ClientTargets[]
  foods: FoodEntry[]
  savedFoods: SavedFood[]
  metrics: DailyMetric[]
}

export const DEMO_COACH_EMAIL = 'coach@demo.dayzero'

// Small deterministic PRNG so the demo looks the same on every reset.
function mulberry32(seed: number) {
  let a = seed
  return () => {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

type Food = [name: string, cal: number, p: number, c: number, f: number]

const LIBRARY: Record<'breakfast' | 'lunch' | 'dinner' | 'snack', Food[]> = {
  breakfast: [
    ['Greek yogurt + berries', 260, 24, 32, 4],
    ['3 eggs + toast', 390, 22, 28, 20],
    ['Protein oats', 420, 32, 55, 9],
    ['Egg white wrap', 330, 30, 30, 9],
    ['Congee with egg', 310, 14, 48, 7],
  ],
  lunch: [
    ['Chicken rice bowl', 620, 45, 70, 15],
    ['Turkey sandwich', 480, 34, 48, 14],
    ['Poke bowl', 650, 38, 78, 18],
    ['Chipotle burrito bowl', 720, 48, 72, 24],
    ['Beef pho', 560, 32, 70, 14],
  ],
  dinner: [
    ['Salmon, rice, broccoli', 640, 42, 58, 24],
    ['Steak + potatoes', 760, 55, 52, 34],
    ['Chicken stir fry', 580, 44, 56, 18],
    ['Pasta with meat sauce', 780, 38, 96, 24],
    ['Tofu + veggie curry', 540, 26, 60, 20],
  ],
  snack: [
    ['Protein shake', 160, 30, 4, 2],
    ['Apple + peanut butter', 290, 8, 30, 16],
    ['Beef jerky', 140, 22, 8, 2],
    ['Protein bar', 210, 20, 22, 7],
    ['Chips', 300, 4, 34, 18],
  ],
}

interface Persona {
  name: string
  email: string
  leadSource: Client['leadSource']
  stage: Client['stage']
  tier: Client['programTier']
  goal: Client['goal']
  weeksIn: number // how many weeks of logs (0 = no logs)
  startWeight: number
  weeklyChange: number // lbs per week
  targets: { calories: number; proteinG: number; carbsG: number; fatG: number; dailySteps: number; goal: number }
  adherence: number // 0..1, chance of logging on a given day
  overeat: number // typical calorie bias vs target, e.g. 0.05 = +5%
  steps: number
  notes: string
}

const PERSONAS: Persona[] = [
  {
    name: 'Jordan Reyes', email: 'jordan@demo.dayzero', leadSource: 'referral', stage: 'active', tier: 'tier_2',
    goal: 'fat_loss', weeksIn: 10, startWeight: 198, weeklyChange: -1.1,
    targets: { calories: 2100, proteinG: 180, carbsG: 190, fatG: 70, dailySteps: 9000, goal: 180 },
    adherence: 0.9, overeat: 0.02, steps: 9500, notes: 'Wants to drop to 180 before summer. Loves Chipotle.',
  },
  {
    name: 'Priya Shah', email: 'priya@demo.dayzero', leadSource: 'social', stage: 'active', tier: 'tier_1',
    goal: 'recomp', weeksIn: 8, startWeight: 142, weeklyChange: -0.2,
    targets: { calories: 1800, proteinG: 130, carbsG: 190, fatG: 55, dailySteps: 8000, goal: 138 },
    adherence: 0.75, overeat: 0.06, steps: 7200, notes: 'Lifts 4x/week. Weekends are the hard part.',
  },
  {
    name: 'Marcus Lee', email: 'marcus@demo.dayzero', leadSource: 'gym', stage: 'active', tier: 'tier_3',
    goal: 'muscle_gain', weeksIn: 12, startWeight: 165, weeklyChange: 0.4,
    targets: { calories: 2900, proteinG: 175, carbsG: 360, fatG: 85, dailySteps: 7000, goal: 175 },
    adherence: 0.85, overeat: -0.08, steps: 8100, notes: 'Hardgainer. Struggles to hit calories.',
  },
  {
    name: 'Danielle Ortiz', email: 'danielle@demo.dayzero', leadSource: 'email_list', stage: 'beta', tier: 'beta',
    goal: 'fat_loss', weeksIn: 5, startWeight: 176, weeklyChange: -0.9,
    targets: { calories: 1700, proteinG: 140, carbsG: 160, fatG: 55, dailySteps: 10000, goal: 160 },
    adherence: 0.6, overeat: 0.1, steps: 6400, notes: 'Beta cohort. Busy nurse schedule, 12h shifts.',
  },
  {
    name: 'Kevin Tran', email: 'kevin@demo.dayzero', leadSource: 'referral', stage: 'beta', tier: 'beta',
    goal: 'maintenance', weeksIn: 4, startWeight: 158, weeklyChange: 0,
    targets: { calories: 2300, proteinG: 150, carbsG: 260, fatG: 70, dailySteps: 8000, goal: 158 },
    adherence: 0.8, overeat: 0, steps: 11000, notes: 'Marathon training block. Keep weight stable.',
  },
  {
    name: 'Alyssa Brooks', email: 'alyssa@demo.dayzero', leadSource: 'social', stage: 'consult', tier: 'tier_1',
    goal: 'fat_loss', weeksIn: 0, startWeight: 0, weeklyChange: 0,
    targets: { calories: 1750, proteinG: 130, carbsG: 170, fatG: 60, dailySteps: 8000, goal: 145 },
    adherence: 0, overeat: 0, steps: 0, notes: 'Consult booked. Found us on TikTok.',
  },
  {
    name: 'Sam Patel', email: 'sam@demo.dayzero', leadSource: 'gym', stage: 'lead', tier: 'tier_1',
    goal: 'muscle_gain', weeksIn: 0, startWeight: 0, weeklyChange: 0,
    targets: { calories: 2600, proteinG: 170, carbsG: 300, fatG: 80, dailySteps: 7000, goal: 170 },
    adherence: 0, overeat: 0, steps: 0, notes: 'Met at the gym, asked about programming.',
  },
  {
    name: 'Erin Walsh', email: 'erin@demo.dayzero', leadSource: 'email_list', stage: 'paused', tier: 'tier_1',
    goal: 'fat_loss', weeksIn: 6, startWeight: 189, weeklyChange: -0.6,
    targets: { calories: 1900, proteinG: 145, carbsG: 190, fatG: 62, dailySteps: 8000, goal: 170 },
    adherence: 0.5, overeat: 0.08, steps: 5800, notes: 'Paused for travel. Follow up after the holidays.',
  },
]

const iso = (d: Date) => format(d, 'yyyy-MM-dd')

export function buildDemoDb(today = new Date()): DemoDb {
  const rand = mulberry32(20261107)
  const noise = (scale: number) => (rand() - 0.5) * 2 * scale
  const pick = <T,>(arr: T[]) => arr[Math.floor(rand() * arr.length)]

  const db: DemoDb = { schemaVersion: 1, clients: [], targets: [], foods: [], savedFoods: [], metrics: [] }
  let seq = 0
  const id = (p: string) => `${p}_${(++seq).toString(36)}`
  const thisMonday = startOfWeek(today, { weekStartsOn: 1 })

  PERSONAS.forEach((p, i) => {
    const start = p.weeksIn > 0 ? subWeeks(thisMonday, p.weeksIn - 1) : null
    const clientId = `client_${i + 1}`
    const checkIn = addDays(today, (i % 6) + 1)
    db.clients.push({
      id: clientId,
      profileId: null,
      name: p.name,
      email: p.email,
      leadSource: p.leadSource,
      stage: p.stage,
      programTier: p.tier,
      goal: p.goal,
      startDate: start ? iso(start) : null,
      nextCheckInDate: ['active', 'beta'].includes(p.stage) ? iso(checkIn) : null,
      notes: p.notes,
      createdAt: (start ?? today).toISOString(),
    })
    const { goal, ...t } = p.targets
    db.targets.push({ id: id('tgt'), clientId, effectiveFrom: iso(start ?? today), ...t, goalWeightLbs: goal })

    if (!start) return
    // Paused clients stopped logging two weeks ago.
    const lastDay = p.stage === 'paused' ? addDays(today, -14) : today
    let weight = p.startWeight
    for (let d = start; d <= lastDay; d = addDays(d, 1)) {
      const date = iso(d)
      const isToday = date === iso(today)
      const weekend = d.getDay() === 0 || d.getDay() === 6
      weight += p.weeklyChange / 7

      // Weight: most mornings, with water-weight noise.
      if (rand() < 0.85) {
        db.metrics.push({
          id: id('m'),
          clientId,
          date,
          weightLbs: Math.round((weight + noise(1.4)) * 10) / 10,
          steps: isToday ? null : Math.max(800, Math.round(p.steps * (weekend ? 0.8 : 1.05) + noise(2500))),
          note: null,
        })
      }

      // Food: skip some days; weekends drift higher.
      if (rand() > p.adherence) continue
      const meals: (keyof typeof LIBRARY)[] = isToday
        ? ['breakfast', 'lunch']
        : ['breakfast', 'lunch', 'dinner', ...(rand() < 0.7 ? (['snack'] as const) : [])]
      const bias = 1 + p.overeat + (weekend ? 0.12 : 0) + noise(0.08)
      const scale = (p.targets.calories * bias) / 1950
      meals.forEach((meal, mi) => {
        const [name, cal, pr, c, f] = pick(LIBRARY[meal])
        const servings = Math.max(0.5, Math.round(scale * 4) / 4)
        db.foods.push({
          id: id('f'),
          clientId,
          date,
          meal,
          name,
          calories: cal,
          proteinG: pr,
          carbsG: c,
          fatG: f,
          servings,
          createdAt: new Date(d.getTime() + (8 + mi * 4) * 3600_000).toISOString(),
        })
      })
    }

    // A few saved favorites per client.
    ;(['breakfast', 'lunch', 'snack'] as const).forEach((meal) => {
      const [name, calories, proteinG, carbsG, fatG] = pick(LIBRARY[meal])
      db.savedFoods.push({ id: id('s'), clientId, name, calories, proteinG, carbsG, fatG })
    })
  })

  return db
}
