import { useState, type FormEvent } from 'react'
import { Button, ErrorNote, Field, fmt, Select, Sheet } from '../../components/ui'
import { useAddFood, useDeleteSavedFood, useSavedFoods, useSaveFood } from '../../hooks/useData'
import { caloriesFromMacros, macroMismatch } from '../../lib/nutrition'
import { LABELS, MEALS, NewFoodEntrySchema, type FoodEntry, type FoodInput, type Meal } from '../../schemas'
import { MacroLine } from './TodayPage'

type Tab = 'quick' | 'saved' | 'recent'

interface Form {
  name: string
  calories: string
  proteinG: string
  carbsG: string
  fatG: string
  servings: string
}

const empty: Form = { name: '', calories: '', proteinG: '', carbsG: '', fatG: '', servings: '1' }
const toForm = (f: FoodInput): Form => ({
  name: f.name,
  calories: String(f.calories),
  proteinG: String(f.proteinG),
  carbsG: String(f.carbsG),
  fatG: String(f.fatG),
  servings: '1',
})
const n = (s: string) => (s.trim() === '' ? 0 : Number(s))

export function AddFoodSheet({
  clientId,
  date,
  meal: initialMeal,
  recent,
  onClose,
}: {
  clientId: string
  date: string
  meal: Meal
  recent: FoodEntry[]
  onClose: () => void
}) {
  const [tab, setTab] = useState<Tab>('quick')
  const [meal, setMeal] = useState<Meal>(initialMeal)
  const [form, setForm] = useState<Form>(empty)
  const [remember, setRemember] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  const saved = useSavedFoods(clientId)
  const add = useAddFood(clientId)
  const saveFood = useSaveFood(clientId)
  const deleteSaved = useDeleteSavedFood(clientId)

  const set = (k: keyof Form) => (e: { target: { value: string } }) => {
    setForm((f) => ({ ...f, [k]: e.target.value }))
    setErrors((er) => ({ ...er, [k]: '' }))
  }

  const p = n(form.proteinG)
  const c = n(form.carbsG)
  const f = n(form.fatG)
  const fromMacros = caloriesFromMacros(p, c, f)
  const mismatch = macroMismatch(n(form.calories), p, c, f)

  function pick(food: FoodInput) {
    setForm(toForm(food))
    setRemember(false)
    setTab('quick')
  }

  async function submit(e: FormEvent) {
    e.preventDefault()
    // Calories left blank but macros given → use the macro math.
    const calories = form.calories.trim() === '' && fromMacros > 0 ? fromMacros : n(form.calories)
    const parsed = NewFoodEntrySchema.safeParse({
      clientId,
      date,
      meal,
      name: form.name,
      calories,
      proteinG: p,
      carbsG: c,
      fatG: f,
      servings: n(form.servings),
    })
    if (!parsed.success) {
      const errs: Record<string, string> = {}
      for (const issue of parsed.error.issues) errs[String(issue.path[0])] = issue.message
      if (errs.calories) errs.calories = 'Enter calories, or fill in the macros'
      setErrors(errs)
      return
    }
    await add.mutateAsync(parsed.data)
    if (remember) {
      const { name, calories: cal, proteinG, carbsG, fatG } = parsed.data
      await saveFood.mutateAsync({ name, calories: cal, proteinG, carbsG, fatG })
    }
    onClose()
  }

  const tabBtn = (t: Tab, label: string) => (
    <button
      type="button"
      onClick={() => setTab(t)}
      className={`flex-1 rounded-lg py-2 text-sm font-semibold ${tab === t ? 'bg-surface text-ink shadow-sm' : 'text-muted'}`}
      aria-pressed={tab === t}
    >
      {label}
    </button>
  )

  return (
    <Sheet title="Log food" onClose={onClose}>
      <div className="mb-4 flex gap-1 rounded-xl bg-ink/5 p-1">
        {tabBtn('quick', 'Enter')}
        {tabBtn('saved', 'My foods')}
        {tabBtn('recent', 'Recent')}
      </div>

      {tab === 'quick' && (
        <form onSubmit={submit} className="space-y-3">
          <Select label="Meal" value={meal} options={MEALS} labels={LABELS.meal} onChange={setMeal} />
          <Field label="Food" value={form.name} onChange={set('name')} placeholder="Chicken rice bowl" error={errors.name} autoFocus />
          <div className="grid grid-cols-2 gap-3">
            <Field
              label="Calories"
              type="number"
              inputMode="numeric"
              value={form.calories}
              onChange={set('calories')}
              placeholder={fromMacros > 0 ? String(fromMacros) : '0'}
              error={errors.calories}
            />
            <Field label="Servings" type="number" inputMode="decimal" step="0.25" value={form.servings} onChange={set('servings')} error={errors.servings} />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <Field label="Protein g" type="number" inputMode="decimal" value={form.proteinG} onChange={set('proteinG')} placeholder="0" />
            <Field label="Carbs g" type="number" inputMode="decimal" value={form.carbsG} onChange={set('carbsG')} placeholder="0" />
            <Field label="Fat g" type="number" inputMode="decimal" value={form.fatG} onChange={set('fatG')} placeholder="0" />
          </div>

          {mismatch !== null ? (
            <p className="rounded-xl bg-carbs/15 px-3 py-2 text-sm">
              These macros add up to about <b>{fmt(mismatch)}</b> calories, not {fmt(n(form.calories))}.{' '}
              <button type="button" className="font-semibold text-cobalt" onClick={() => setForm((x) => ({ ...x, calories: String(mismatch) }))}>
                Use {fmt(mismatch)}
              </button>
            </p>
          ) : form.calories.trim() === '' && fromMacros > 0 ? (
            <p className="text-sm text-muted">Calories will be set from macros: {fmt(fromMacros)}.</p>
          ) : null}

          <label className="flex items-center gap-2 py-1 text-[15px]">
            <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} className="h-5 w-5 accent-[var(--color-cobalt)]" />
            Save to My foods
          </label>

          {add.error ? <ErrorNote error={add.error} /> : null}
          <Button className="w-full" disabled={add.isPending}>
            {add.isPending ? 'Logging…' : `Log to ${LABELS.meal[meal]}`}
          </Button>
        </form>
      )}

      {tab === 'saved' && (
        <FoodList
          items={saved.data ?? []}
          empty="Nothing saved yet. Tick “Save to My foods” when you log something you eat often."
          onPick={pick}
          onDelete={(s) => deleteSaved.mutate(s.id)}
        />
      )}

      {tab === 'recent' && <FoodList items={recent} empty="Foods you log will show up here." onPick={pick} />}
    </Sheet>
  )
}

function FoodList<T extends FoodInput & { id: string }>({
  items,
  empty,
  onPick,
  onDelete,
}: {
  items: T[]
  empty: string
  onPick: (f: T) => void
  onDelete?: (f: T) => void
}) {
  if (!items.length) return <p className="py-8 text-center text-muted">{empty}</p>
  return (
    <ul className="divide-y divide-line">
      {items.map((it) => (
        <li key={it.id} className="flex items-center gap-2">
          <button className="flex min-w-0 flex-1 items-center justify-between py-3 text-left" onClick={() => onPick(it)}>
            <span className="min-w-0">
              <span className="block truncate">{it.name}</span>
              <MacroLine p={it.proteinG} c={it.carbsG} f={it.fatG} />
            </span>
            <span className="num ml-3 font-semibold">{fmt(it.calories)}</span>
          </button>
          {onDelete && (
            <button
              aria-label={`Remove ${it.name} from My foods`}
              className="rounded-md px-2 py-1 text-sm text-muted hover:bg-warn/10 hover:text-warn"
              onClick={() => onDelete(it)}
            >
              ✕
            </button>
          )}
        </li>
      ))}
    </ul>
  )
}

