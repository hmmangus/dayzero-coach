import type {
  Client,
  ClientTargets,
  DailyMetric,
  FoodEntry,
  FoodInput,
  NewClient,
  NewFoodEntry,
  SavedFood,
  TargetsInput,
} from '../schemas'

export type Role = 'coach' | 'client'

export interface Viewer {
  userId: string
  email: string
  role: Role
}

export interface DailyMetricPatch {
  weightLbs?: number | null
  steps?: number | null
  note?: string | null
}

/**
 * The only way UI code touches data. Two implementations exist:
 * SupabaseRepository (real, multi-user) and DemoRepository (localStorage).
 * Access control is enforced by the database (RLS), not by this interface.
 */
export interface Repository {
  readonly mode: 'supabase' | 'demo'

  // Auth
  getViewer(): Promise<Viewer | null>
  signIn(email: string): Promise<{ message: string }>
  signOut(): Promise<void>
  onAuthChange(cb: () => void): () => void

  // Clients
  getMyClient(): Promise<Client | null>
  listClients(): Promise<Client[]>
  getClient(id: string): Promise<Client | null>
  createClient(input: NewClient, targets: TargetsInput): Promise<Client>
  updateClient(id: string, patch: Partial<NewClient>): Promise<Client>

  // Targets (versioned: newest effectiveFrom wins from that date on)
  listTargets(clientId: string): Promise<ClientTargets[]>
  setTargets(clientId: string, targets: TargetsInput, effectiveFrom: string): Promise<ClientTargets>

  // Food log
  listFoodEntries(clientId: string, from: string, to: string): Promise<FoodEntry[]>
  addFoodEntry(entry: NewFoodEntry): Promise<FoodEntry>
  deleteFoodEntry(id: string): Promise<void>

  // Saved foods
  listSavedFoods(clientId: string): Promise<SavedFood[]>
  saveFood(clientId: string, food: FoodInput): Promise<SavedFood>
  deleteSavedFood(id: string): Promise<void>

  // Weight / steps
  listDailyMetrics(clientId: string, from: string, to: string): Promise<DailyMetric[]>
  upsertDailyMetric(clientId: string, date: string, patch: DailyMetricPatch): Promise<DailyMetric>
}
