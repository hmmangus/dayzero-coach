import { useState, type FormEvent } from 'react'
import { Button, ErrorNote, Field, Sheet } from '../../components/ui'
import { useUpsertMetric } from '../../hooks/useData'
import { prettyDay } from '../../lib/dates'

export function MetricSheet({
  clientId,
  date,
  kind,
  current,
  onClose,
}: {
  clientId: string
  date: string
  kind: 'weight' | 'steps'
  current: number | null
  onClose: () => void
}) {
  const [value, setValue] = useState(current?.toString() ?? '')
  const [error, setError] = useState<string | null>(null)
  const save = useUpsertMetric(clientId)
  const isWeight = kind === 'weight'

  function submit(e: FormEvent) {
    e.preventDefault()
    const n = value.trim() === '' ? null : Number(value)
    if (n !== null && (!Number.isFinite(n) || n < 0 || (isWeight && (n < 50 || n > 700)))) {
      setError(isWeight ? 'Enter a weight in pounds, like 182.4' : 'Enter a whole number of steps')
      return
    }
    save.mutate(
      { date, patch: isWeight ? { weightLbs: n } : { steps: n === null ? null : Math.round(n) } },
      { onSuccess: onClose },
    )
  }

  return (
    <Sheet title={isWeight ? 'Log weight' : 'Log steps'} onClose={onClose}>
      <form onSubmit={submit} className="space-y-4">
        <Field
          label={isWeight ? `Weight (lbs) for ${prettyDay(date)}` : `Steps for ${prettyDay(date)}`}
          type="number"
          inputMode={isWeight ? 'decimal' : 'numeric'}
          step={isWeight ? '0.1' : '1'}
          autoFocus
          value={value}
          onChange={(e) => {
            setValue(e.target.value)
            setError(null)
          }}
          error={error ?? undefined}
          hint={isWeight ? 'Weigh in the morning, after the bathroom, before food.' : 'Copy the total from your phone or watch.'}
        />
        {save.error ? <ErrorNote error={save.error} /> : null}
        <Button className="w-full" disabled={save.isPending}>
          {save.isPending ? 'Saving…' : isWeight ? 'Save weight' : 'Save steps'}
        </Button>
        {current !== null && (
          <Button
            type="button"
            variant="danger"
            className="w-full"
            onClick={() => save.mutate({ date, patch: isWeight ? { weightLbs: null } : { steps: null } }, { onSuccess: onClose })}
          >
            Clear
          </Button>
        )}
      </form>
    </Sheet>
  )
}
