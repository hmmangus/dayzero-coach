import { useState, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { Button, ErrorNote, Field, Select, Sheet } from '../../components/ui'
import { useCreateClient } from '../../hooks/useData'
import { todayIso } from '../../lib/dates'
import { GOALS, LABELS, LEAD_SOURCES, NewClientSchema, STAGES, TargetsInputSchema, TIERS, type NewClient } from '../../schemas'
import { TargetFields, targetsToForm, type TargetForm, parseTargetForm } from './TargetFields'

export function NewClientSheet({ onClose }: { onClose: () => void }) {
  const nav = useNavigate()
  const create = useCreateClient()
  const [c, setC] = useState<NewClient>({
    name: '',
    email: '',
    leadSource: 'referral',
    stage: 'active',
    programTier: 'tier_1',
    goal: 'fat_loss',
    startDate: todayIso(),
    nextCheckInDate: null,
    notes: '',
  })
  const [t, setT] = useState<TargetForm>(
    targetsToForm({ calories: 2000, proteinG: 150, carbsG: 200, fatG: 65, dailySteps: 8000, goalWeightLbs: null }),
  )
  const [errors, setErrors] = useState<Record<string, string>>({})

  async function submit(e: FormEvent) {
    e.preventDefault()
    const client = NewClientSchema.safeParse({ ...c, email: c.email.trim().toLowerCase(), name: c.name.trim() })
    const targets = TargetsInputSchema.safeParse(parseTargetForm(t))
    const errs: Record<string, string> = {}
    if (!client.success) for (const i of client.error.issues) errs[String(i.path[0])] = i.message
    if (!targets.success) for (const i of targets.error.issues) errs[`t.${String(i.path[0])}`] = 'Enter a number'
    setErrors(errs)
    if (!client.success || !targets.success) return
    const created = await create.mutateAsync({ client: client.data, targets: targets.data })
    onClose()
    nav(`/clients/${created.id}`)
  }

  return (
    <Sheet title="Add client" onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <Field label="Name" value={c.name} onChange={(e) => setC({ ...c, name: e.target.value })} error={errors.name} autoFocus />
        <Field
          label="Email"
          type="email"
          value={c.email}
          onChange={(e) => setC({ ...c, email: e.target.value })}
          error={errors.email}
          hint="They sign in with this email to start logging."
        />
        <div className="grid grid-cols-2 gap-3">
          <Select label="Stage" value={c.stage} options={STAGES} labels={LABELS.stage} onChange={(stage) => setC({ ...c, stage })} />
          <Select label="Lead source" value={c.leadSource} options={LEAD_SOURCES} labels={LABELS.leadSource} onChange={(leadSource) => setC({ ...c, leadSource })} />
          <Select label="Program" value={c.programTier} options={TIERS} labels={LABELS.tier} onChange={(programTier) => setC({ ...c, programTier })} />
          <Select label="Goal" value={c.goal} options={GOALS} labels={LABELS.goal} onChange={(goal) => setC({ ...c, goal })} />
          <Field label="Start date" type="date" value={c.startDate ?? ''} onChange={(e) => setC({ ...c, startDate: e.target.value || null })} />
          <Field
            label="Next check-in"
            type="date"
            value={c.nextCheckInDate ?? ''}
            onChange={(e) => setC({ ...c, nextCheckInDate: e.target.value || null })}
          />
        </div>
        <h3 className="pt-3 font-semibold">Daily targets</h3>
        <TargetFields value={t} onChange={setT} errors={errors} />
        {create.error ? <ErrorNote error={create.error} /> : null}
        <Button className="w-full" disabled={create.isPending}>
          {create.isPending ? 'Adding…' : 'Add client'}
        </Button>
      </form>
    </Sheet>
  )
}
