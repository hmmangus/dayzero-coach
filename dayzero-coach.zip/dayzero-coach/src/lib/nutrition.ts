import type { ClientTargets, FoodEntry } from '../schemas'

export interface Totals {
  calories: number
  proteinG: number
  carbsG: number
  fatG: number
}

export const ZERO: Totals = { calories: 0, proteinG: 0, carbsG: 0, fatG: 0 }

/** Atwater factors: 4 kcal/g protein and carbs, 9 kcal/g fat. */
export const caloriesFromMacros = (p: number, c: number, f: number) => Math.round(p * 4 + c * 4 + f * 9)

/**
 * Flags an entry whose stated calories disagree with its macros by more
 * than 15% and 50 kcal (fiber and rounding cause small honest gaps).
 */
export function macroMismatch(calories: number, p: number, c: number, f: number): number | null {
  const fromMacros = caloriesFromMacros(p, c, f)
  if (fromMacros === 0 || calories === 0) return null
  const diff = Math.abs(calories - fromMacros)
  return diff > 50 && diff / Math.max(calories, fromMacros) > 0.15 ? fromMacros : null
}

export function entryTotals(e: Pick<FoodEntry, 'calories' | 'proteinG' | 'carbsG' | 'fatG' | 'servings'>): Totals {
  return {
    calories: e.calories * e.servings,
    proteinG: e.proteinG * e.servings,
    carbsG: e.carbsG * e.servings,
    fatG: e.fatG * e.servings,
  }
}

export function sumTotals(entries: Parameters<typeof entryTotals>[0][]): Totals {
  return entries.reduce<Totals>((acc, e) => {
    const t = entryTotals(e)
    return {
      calories: acc.calories + t.calories,
      proteinG: acc.proteinG + t.proteinG,
      carbsG: acc.carbsG + t.carbsG,
      fatG: acc.fatG + t.fatG,
    }
  }, ZERO)
}

/** Daily totals keyed by date. Only dates with at least one entry appear. */
export function dailyTotals(entries: FoodEntry[]): Map<string, Totals> {
  const byDay = new Map<string, FoodEntry[]>()
  for (const e of entries) byDay.set(e.date, [...(byDay.get(e.date) ?? []), e])
  return new Map([...byDay].map(([d, es]) => [d, sumTotals(es)]))
}

/** The target version in effect on a date: newest with effectiveFrom <= date. */
export function targetsOn(targets: ClientTargets[], date: string): ClientTargets | null {
  let best: ClientTargets | null = null
  for (const t of targets) {
    if (t.effectiveFrom <= date && (!best || t.effectiveFrom > best.effectiveFrom)) best = t
  }
  // Before the first version existed, fall back to the earliest one.
  if (!best && targets.length) best = [...targets].sort((a, b) => a.effectiveFrom.localeCompare(b.effectiveFrom))[0]
  return best
}

export const round = (n: number, dp = 0) => {
  const m = 10 ** dp
  return Math.round(n * m) / m
}
