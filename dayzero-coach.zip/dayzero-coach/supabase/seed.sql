-- OPTIONAL sample data so the coach dashboard isn't empty on day one.
-- All names are fictional (@example.com addresses). Run in Supabase → SQL Editor.
-- Remove it before onboarding real clients with:
--   delete from public.clients where email like '%@example.com';

do $$
declare
  c record;
  cid uuid;
  d date;
  w numeric;
  bias numeric;
  meals text[] := array['breakfast', 'lunch', 'dinner', 'snack'];
  foods jsonb := '{
    "breakfast": [["Greek yogurt + berries",260,24,32,4],["3 eggs + toast",390,22,28,20],["Protein oats",420,32,55,9]],
    "lunch":     [["Chicken rice bowl",620,45,70,15],["Turkey sandwich",480,34,48,14],["Poke bowl",650,38,78,18]],
    "dinner":    [["Salmon, rice, broccoli",640,42,58,24],["Steak + potatoes",760,55,52,34],["Chicken stir fry",580,44,56,18]],
    "snack":     [["Protein shake",160,30,4,2],["Apple + peanut butter",290,8,30,16],["Protein bar",210,20,22,7]]
  }';
  m text;
  f jsonb;
  start_day date := date_trunc('week', current_date)::date - 7 * 7;  -- 8 weeks of history
begin
  for c in
    select * from (values
      ('Jordan Reyes',   'jordan@example.com',   'referral',   'active', 'tier_2', 'fat_loss',    198.0, -1.1, 2100, 180, 190, 70, 9000, 180.0, 0.90),
      ('Priya Shah',     'priya@example.com',    'social',     'active', 'tier_1', 'recomp',      142.0, -0.2, 1800, 130, 190, 55, 8000, 138.0, 0.75),
      ('Marcus Lee',     'marcus@example.com',   'gym',        'active', 'tier_3', 'muscle_gain', 165.0,  0.4, 2900, 175, 360, 85, 7000, 175.0, 0.85),
      ('Danielle Ortiz', 'danielle@example.com', 'email_list', 'beta',   'beta',   'fat_loss',    176.0, -0.9, 1700, 140, 160, 55, 10000, 160.0, 0.60)
    ) as t(name, email, src, stage, tier, goal, w0, wk, cal, p, cb, fa, steps, gw, adherence)
  loop
    insert into public.clients (name, email, lead_source, stage, program_tier, goal, start_date, next_check_in_date, notes)
    values (c.name, c.email, c.src, c.stage, c.tier, c.goal, start_day, current_date + 3, 'Sample client')
    returning id into cid;

    insert into public.client_targets (client_id, effective_from, calories, protein_g, carbs_g, fat_g, daily_steps, goal_weight_lbs)
    values (cid, start_day, c.cal, c.p, c.cb, c.fa, c.steps, c.gw);

    w := c.w0;
    d := start_day;
    while d <= current_date loop
      w := w + c.wk / 7.0;
      insert into public.daily_metrics (client_id, date, weight_lbs, steps)
      values (cid, d, round((w + (random() - 0.5) * 2.4)::numeric, 1),
              greatest(800, round((c.steps * (0.8 + random() * 0.4))::numeric))::int);

      if random() < c.adherence then
        bias := (c.cal / 1950.0 * (0.9 + random() * 0.25))::numeric;
        foreach m in array meals loop
          continue when m = 'snack' and random() < 0.3;
          f := foods -> m -> floor(random() * 3)::int;
          insert into public.food_entries (client_id, date, meal, name, calories, protein_g, carbs_g, fat_g, servings)
          values (cid, d, m, f ->> 0, (f ->> 1)::numeric, (f ->> 2)::numeric, (f ->> 3)::numeric,
                  (f ->> 4)::numeric, greatest(0.5, round(bias * 4) / 4));
        end loop;
      end if;
      d := d + 1;
    end loop;
  end loop;
end $$;
