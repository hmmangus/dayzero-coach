import { useQueries } from '@tanstack/react-query'
import { repo } from '../../data'
import { keys } from '../../hooks/useData'
import { daysBetween, shiftIso, todayIso, weekStartIso } from '../../lib/dates'
import { buildWeeklySummaries, lastLoggedDate, type WeekSummary } from '../../lib/weekly'
import type { Client } from '../../schemas'

export interface ClientRowStats {
  thisWeek: WeekSummary | null
  lastWeek: WeekSummary | null
  lastLogged: string | null
  daysSinceLog: number | null
  needsAttention: boolean
  loading: boolean
}

/** This week + last week for every client, for the roster table. */
export function useRosterStats(clients: Client[]): Map<string, ClientRowStats> {
  const today = todayIso()
  const from = shiftIso(weekStartIso(today), -7)

  const results = useQueries({
    queries: clients.flatMap((c) => [
      { queryKey: keys.food(c.id, from, today), queryFn: () => repo.listFoodEntries(c.id, from, today) },
      { queryKey: keys.metrics(c.id, from, today), queryFn: () => repo.listDailyMetrics(c.id, from, today) },
      { queryKey: keys.targets(c.id), queryFn: () => repo.listTargets(c.id) },
    ]),
  })

  const map = new Map<string, ClientRowStats>()
  clients.forEach((c, i) => {
    const [food, metrics, targets] = results.slice(i * 3, i * 3 + 3)
    if (!food?.data || !metrics?.data || !targets?.data) {
      map.set(c.id, { thisWeek: null, lastWeek: null, lastLogged: null, daysSinceLog: null, needsAttention: false, loading: true })
      return
    }
    const entries = food.data as Awaited<ReturnType<typeof repo.listFoodEntries>>
    const weeks = buildWeeklySummaries({
      entries,
      metrics: metrics.data as Awaited<ReturnType<typeof repo.listDailyMetrics>>,
      targets: targets.data as Awaited<ReturnType<typeof repo.listTargets>>,
      from,
      to: today,
      inProgressDate: today,
    })
    const lastLogged = lastLoggedDate(entries)
    const daysSinceLog = lastLogged ? daysBetween(lastLogged, today).length - 1 : null
    const coaching = c.stage === 'active' || c.stage === 'beta'
    map.set(c.id, {
      thisWeek: weeks.at(-1) ?? null,
      lastWeek: weeks.length > 1 ? weeks[0] : null,
      lastLogged,
      daysSinceLog,
      needsAttention: coaching && (daysSinceLog === null || daysSinceLog >= 3),
      loading: false,
    })
  })
  return map
}
