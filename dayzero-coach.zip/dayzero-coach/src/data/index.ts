import { DemoRepository } from './demoRepository'
import type { Repository } from './repository'
import { SupabaseRepository } from './supabaseRepository'

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined

/** Supabase when configured, otherwise a self-contained demo backed by localStorage. */
export const repo: Repository = url && key ? new SupabaseRepository(url, key) : new DemoRepository()

export type { Repository, Role, Viewer } from './repository'
