import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { MacroBar, Ring } from '../../components/Ring'
import { Button, ErrorNote, fmt, Spinner } from '../../components/ui'
import { useDeleteFood, useFood, useMetrics, useTargets } from '../../hooks/useData'
import { prettyDay, shiftIso, todayIso } from '../../lib/dates'
import { entryTotals, sumTotals, targetsOn } from '../../lib/nutrition'
import { loggingStreak } from '../../lib/weekly'
import { LABELS, MEALS, type FoodEntry, type Meal } from '../../schemas'
import { AddFoodSheet } from './AddFoodSheet'
import { useCurrentClient } from './ClientShell'
import { MetricSheet } from './MetricSheet'

export function TodayPage() {
  const client = useCurrentClient()
  const [params, setParams] = useSearchParams()
  const today = todayIso()
  const date = params.get('d') && params.get('d')! <= today ? params.get('d')! : today
  const setDate = (d: string) => setParams(d === today ? {} : { d })

  const from = shiftIso(date, -60)
  const food = useFood(client.id, from, today)
  const metrics = useMetrics(client.id, date, date)
  const targets = useTargets(client.id)
  const del = useDeleteFood(client.id)

  const [adding, setAdding] = useState<Meal | null>(null)
  const [metricSheet, setMetricSheet] = useState<'weight' | 'steps' | null>(null)

  const dayEntries = useMemo(() => (food.data ?? []).filter((e) => e.date === date), [food.data, date])
  const recent = useMemo(() => recentFoods(food.data ?? []), [food.data])
  const streak = useMemo(() => loggingStreak((food.data ?? []).map((e) => e.date), today), [food.data, today])

  if (food.isLoading || targets.isLoading) return <Spinner />
  if (food.error) return <div className="p-6"><ErrorNote error={food.error} /></div>

  const t = targetsOn(targets.data ?? [], date)
  const totals = sumTotals(dayEntries)
  const metric = metrics.data?.[0]
  const goal = t?.calories ?? 0
  const left = goal - totals.calories

  return (
    <main className="px-5 pt-[max(1rem,env(safe-area-inset-top))]">
      <header className="flex items-center justify-between py-2">
        <div className="flex items-center gap-1">
          <button aria-label="Previous day" className="rounded-lg px-2 py-2 text-xl text-muted hover:bg-ink/5" onClick={() => setDate(shiftIso(date, -1))}>
            ‹
          </button>
          <h1 className="num min-w-36 text-center text-xl font-bold">{date === today ? 'Today' : prettyDay(date)}</h1>
          <button
            aria-label="Next day"
            disabled={date >= today}
            className="rounded-lg px-2 py-2 text-xl text-muted hover:bg-ink/5 disabled:opacity-30"
            onClick={() => setDate(shiftIso(date, 1))}
          >
            ›
          </button>
        </div>
        <p className="text-sm text-muted" title="Days in a row with food logged">
          <span className="num text-lg font-bold text-ink">{streak}</span> day streak
        </p>
      </header>

      <section className="mt-2 flex flex-col items-center rounded-[28px] bg-surface px-5 py-6">
        <Ring value={totals.calories} max={goal} label="Calories eaten">
          <div>
            <p className={`num text-[56px] leading-none font-extrabold ${left < 0 ? 'text-warn' : ''}`}>
              {fmt(Math.abs(left))}
            </p>
            <p className="mt-1 text-sm font-medium text-muted">{left < 0 ? 'calories over' : 'calories left'}</p>
          </div>
        </Ring>
        <p className="mt-3 text-sm text-muted">
          {fmt(totals.calories)} eaten of {fmt(goal)}
        </p>
        <div className="mt-6 grid w-full gap-4">
          <MacroBar label="Protein" value={totals.proteinG} target={t?.proteinG ?? 0} color="var(--color-protein)" />
          <MacroBar label="Carbs" value={totals.carbsG} target={t?.carbsG ?? 0} color="var(--color-carbs)" />
          <MacroBar label="Fat" value={totals.fatG} target={t?.fatG ?? 0} color="var(--color-fat)" />
        </div>
      </section>

      <section className="mt-3 grid grid-cols-2 gap-3">
        <button onClick={() => setMetricSheet('steps')} className="rounded-2xl bg-surface p-4 text-left hover:ring-1 hover:ring-line">
          <p className="text-sm font-medium text-muted">Steps</p>
          <p className="num mt-1 text-2xl font-bold">{metric?.steps != null ? fmt(metric.steps) : 'Add'}</p>
          <p className="text-sm text-muted">goal {fmt(t?.dailySteps)}</p>
        </button>
        <button onClick={() => setMetricSheet('weight')} className="rounded-2xl bg-surface p-4 text-left hover:ring-1 hover:ring-line">
          <p className="text-sm font-medium text-muted">Weight</p>
          <p className="num mt-1 text-2xl font-bold">{metric?.weightLbs != null ? `${fmt(metric.weightLbs, 1)}` : 'Add'}</p>
          <p className="text-sm text-muted">lbs, morning</p>
        </button>
      </section>

      <section className="mt-6">
        {MEALS.map((meal) => {
          const items = dayEntries.filter((e) => e.meal === meal)
          const mealCals = sumTotals(items).calories
          return (
            <div key={meal} className="border-t border-line py-3">
              <div className="flex items-center justify-between">
                <h2 className="font-semibold">
                  {LABELS.meal[meal]}
                  {items.length > 0 && <span className="ml-2 text-sm font-normal text-muted">{fmt(mealCals)} cal</span>}
                </h2>
                <button
                  onClick={() => setAdding(meal)}
                  className="rounded-lg px-3 py-1.5 text-sm font-semibold text-cobalt hover:bg-cobalt-soft"
                  aria-label={`Add food to ${LABELS.meal[meal]}`}
                >
                  + Add
                </button>
              </div>
              {items.map((e) => {
                const et = entryTotals(e)
                return (
                  <div key={e.id} className="group flex items-center justify-between py-2">
                    <div className="min-w-0">
                      <p className="truncate">
                        {e.name}
                        {e.servings !== 1 && <span className="text-muted"> × {e.servings}</span>}
                      </p>
                      <MacroLine p={et.proteinG} c={et.carbsG} f={et.fatG} />
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="num font-semibold">{fmt(et.calories)}</span>
                      <button
                        aria-label={`Delete ${e.name}`}
                        onClick={() => del.mutate(e.id)}
                        className="rounded-md px-2 py-1 text-sm text-muted hover:bg-warn/10 hover:text-warn"
                      >
                        ✕
                      </button>
                    </div>
                  </div>
                )
              })}
            </div>
          )
        })}
      </section>

      <div className="fixed inset-x-0 bottom-[calc(3.25rem+env(safe-area-inset-bottom))] z-30 mx-auto flex max-w-md justify-end px-5 pb-3">
        <Button className="h-14 rounded-2xl px-6 shadow-lg shadow-ink/20" onClick={() => setAdding(defaultMeal())}>
          + Log food
        </Button>
      </div>

      {adding && (
        <AddFoodSheet clientId={client.id} date={date} meal={adding} recent={recent} onClose={() => setAdding(null)} />
      )}
      {metricSheet && (
        <MetricSheet
          clientId={client.id}
          date={date}
          kind={metricSheet}
          current={metricSheet === 'weight' ? metric?.weightLbs ?? null : metric?.steps ?? null}
          onClose={() => setMetricSheet(null)}
        />
      )}
    </main>
  )
}

export function MacroLine({ p, c, f }: { p: number; c: number; f: number }) {
  return (
    <p className="flex gap-3 text-sm text-muted">
      <span>
        <b className="font-semibold text-protein">P</b> {fmt(p)}g
      </span>
      <span>
        <b className="font-semibold text-carbs">C</b> {fmt(c)}g
      </span>
      <span>
        <b className="font-semibold text-fat">F</b> {fmt(f)}g
      </span>
    </p>
  )
}

function defaultMeal(): Meal {
  const h = new Date().getHours() + new Date().getMinutes() / 60
  if (h < 10.5) return 'breakfast'
  if (h < 15) return 'lunch'
  if (h < 21) return 'dinner'
  return 'snack'
}

/** Most recently logged unique foods, newest first. */
function recentFoods(entries: FoodEntry[]) {
  const seen = new Set<string>()
  const out: FoodEntry[] = []
  for (const e of [...entries].sort((a, b) => b.createdAt.localeCompare(a.createdAt))) {
    const key = e.name.toLowerCase()
    if (seen.has(key)) continue
    seen.add(key)
    out.push(e)
    if (out.length >= 15) break
  }
  return out
}
