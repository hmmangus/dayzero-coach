import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { repo } from '../../data'
import { AddFoodSheet } from './AddFoodSheet'

function setup(onClose = vi.fn()) {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } })
  render(
    <QueryClientProvider client={qc}>
      <AddFoodSheet clientId="client_test" date="2026-11-07" meal="lunch" recent={[]} onClose={onClose} />
    </QueryClientProvider>,
  )
  return { onClose, user: userEvent.setup() }
}

describe('AddFoodSheet', () => {
  beforeEach(() => localStorage.clear())

  it('logs a food and fills calories from macros when left blank', async () => {
    const { user, onClose } = setup()
    await user.type(screen.getByLabelText('Food'), 'Chicken bowl')
    await user.type(screen.getByLabelText('Protein g'), '40')
    await user.type(screen.getByLabelText('Carbs g'), '60')
    await user.type(screen.getByLabelText('Fat g'), '10')
    expect(screen.getByText(/Calories will be set from macros: 490/)).toBeInTheDocument()

    await user.click(screen.getByRole('button', { name: 'Log to Lunch' }))
    await waitFor(() => expect(onClose).toHaveBeenCalled())

    const saved = await repo.listFoodEntries('client_test', '2026-11-07', '2026-11-07')
    expect(saved).toHaveLength(1)
    expect(saved[0]).toMatchObject({ name: 'Chicken bowl', calories: 490, proteinG: 40, meal: 'lunch', servings: 1 })
  })

  it('blocks logging without a name or calories', async () => {
    const { user, onClose } = setup()
    await user.click(screen.getByRole('button', { name: 'Log to Lunch' }))
    expect(await screen.findByText('Name the food')).toBeInTheDocument()
    expect(onClose).not.toHaveBeenCalled()
  })

  it('warns when calories and macros disagree and offers the fix', async () => {
    const { user } = setup()
    await user.type(screen.getByLabelText('Calories'), '900')
    await user.type(screen.getByLabelText('Protein g'), '30')
    await user.type(screen.getByLabelText('Carbs g'), '40')
    await user.type(screen.getByLabelText('Fat g'), '10')
    await user.click(screen.getByRole('button', { name: 'Use 370' }))
    expect(screen.getByLabelText('Calories')).toHaveValue(370)
  })
})
