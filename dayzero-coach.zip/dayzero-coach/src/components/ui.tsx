import { useEffect, useId, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode } from 'react'

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger'

const variants: Record<Variant, string> = {
  primary: 'bg-ink text-white hover:bg-ink/90 disabled:bg-ink/40',
  secondary: 'bg-surface text-ink border border-line hover:border-ink/40',
  ghost: 'text-ink hover:bg-ink/5',
  danger: 'text-warn hover:bg-warn/10',
}

export function Button({
  variant = 'primary',
  className = '',
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  return (
    <button
      {...props}
      className={`inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 text-[15px] font-semibold transition-colors disabled:cursor-not-allowed ${variants[variant]} ${className}`}
    />
  )
}

export function Field({
  label,
  error,
  hint,
  className = '',
  ...props
}: InputHTMLAttributes<HTMLInputElement> & { label: string; error?: string; hint?: string }) {
  const id = useId()
  return (
    <label htmlFor={id} className={`block ${className}`}>
      <span className="mb-1 block text-sm font-medium text-muted">{label}</span>
      <input
        id={id}
        {...props}
        aria-invalid={!!error}
        className={`h-11 w-full rounded-xl border bg-surface px-3 text-[16px] outline-none transition-colors focus:border-cobalt ${
          error ? 'border-warn' : 'border-line'
        }`}
      />
      {error ? (
        <span className="mt-1 block text-sm text-warn">{error}</span>
      ) : hint ? (
        <span className="mt-1 block text-sm text-muted">{hint}</span>
      ) : null}
    </label>
  )
}

export function Select<T extends string>({
  label,
  value,
  options,
  labels,
  onChange,
}: {
  label: string
  value: T
  options: readonly T[]
  labels: Record<T, string>
  onChange: (v: T) => void
}) {
  const id = useId()
  return (
    <label htmlFor={id} className="block">
      <span className="mb-1 block text-sm font-medium text-muted">{label}</span>
      <select
        id={id}
        value={value}
        onChange={(e) => onChange(e.target.value as T)}
        className="h-11 w-full rounded-xl border border-line bg-surface px-3 text-[16px] outline-none focus:border-cobalt"
      >
        {options.map((o) => (
          <option key={o} value={o}>
            {labels[o]}
          </option>
        ))}
      </select>
    </label>
  )
}

/** Bottom sheet on phones, centered dialog on wider screens. */
export function Sheet({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', onKey)
      document.body.style.overflow = prev
    }
  }, [onClose])

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center" role="dialog" aria-modal aria-label={title}>
      <button aria-label="Close" className="absolute inset-0 bg-ink/40" onClick={onClose} />
      <div className="sheet-enter relative max-h-[92dvh] w-full overflow-y-auto rounded-t-3xl bg-paper px-5 pt-3 pb-[max(1.25rem,env(safe-area-inset-bottom))] sm:max-w-lg sm:rounded-3xl sm:pt-5">
        <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-line sm:hidden" />
        <div className="mb-4 flex items-center justify-between">
          <h2 className="num text-xl font-bold">{title}</h2>
          <button onClick={onClose} className="rounded-lg px-2 py-1 text-sm font-semibold text-muted hover:bg-ink/5">
            Close
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}

export function Spinner({ label = 'Loading' }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-3 py-16 text-muted" role="status">
      <span className="h-4 w-4 animate-spin rounded-full border-2 border-line border-t-ink" />
      {label}
    </div>
  )
}

export function ErrorNote({ error }: { error: unknown }) {
  return (
    <p className="rounded-xl bg-warn/10 px-4 py-3 text-sm text-warn" role="alert">
      {error instanceof Error ? error.message : 'Something went wrong. Refresh and try again.'}
    </p>
  )
}

export const fmt = (n: number | null | undefined, dp = 0) =>
  n === null || n === undefined ? '—' : n.toLocaleString(undefined, { maximumFractionDigits: dp, minimumFractionDigits: 0 })
