import { useState, type FormEvent } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { repo } from '../../data'
import { DEMO_COACH_EMAIL } from '../../data/demoSeed'
import { Button, ErrorNote, Field } from '../../components/ui'

export function LoginPage() {
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState<string | null>(null)
  const [error, setError] = useState<unknown>(null)
  const [busy, setBusy] = useState(false)
  const qc = useQueryClient()

  async function submit(e: FormEvent) {
    e.preventDefault()
    setBusy(true)
    setError(null)
    try {
      const res = await repo.signIn(email)
      setSent(res.message)
    } catch (err) {
      setError(err)
    } finally {
      setBusy(false)
    }
  }

  async function demoAs(addr: string) {
    await repo.signIn(addr)
    qc.invalidateQueries({ queryKey: ['viewer'] })
  }

  return (
    <main className="mx-auto flex min-h-dvh max-w-sm flex-col justify-center px-6 py-12">
      <p className="num text-[56px] leading-none font-extrabold tracking-tight">Day zero.</p>
      <p className="mt-3 text-lg text-muted">Control what you can control. Log it, and your coach sees the week.</p>

      {repo.mode === 'demo' ? (
        <div className="mt-10 space-y-3">
          <p className="text-sm text-muted">
            Demo mode: fake clients, saved only in this browser. Connect Supabase to use it with real clients.
          </p>
          <Button className="w-full" onClick={() => demoAs(DEMO_COACH_EMAIL)}>
            Open the coach dashboard
          </Button>
          <Button variant="secondary" className="w-full" onClick={() => demoAs('jordan@demo.dayzero')}>
            Open the client app as Jordan
          </Button>
        </div>
      ) : sent ? (
        <div className="mt-10 rounded-2xl bg-surface p-5">
          <p className="font-semibold">{sent}</p>
          <p className="mt-1 text-sm text-muted">Open the link on this device to sign in. You can close this tab.</p>
          <button className="mt-4 text-sm font-semibold text-cobalt" onClick={() => setSent(null)}>
            Use a different email
          </button>
        </div>
      ) : (
        <form onSubmit={submit} className="mt-10 space-y-4">
          <Field
            label="Email"
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            hint="Use the email your coach has on file. We'll send a sign-in link."
          />
          {error ? <ErrorNote error={error} /> : null}
          <Button className="w-full" disabled={busy || !email}>
            {busy ? 'Sending…' : 'Send sign-in link'}
          </Button>
        </form>
      )}
    </main>
  )
}
