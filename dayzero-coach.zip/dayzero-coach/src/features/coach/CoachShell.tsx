import { Link, Outlet } from 'react-router-dom'
import { useQueryClient } from '@tanstack/react-query'
import { repo } from '../../data'
import { DemoRepository } from '../../data/demoRepository'
import { Button } from '../../components/ui'

export function CoachShell() {
  const qc = useQueryClient()
  return (
    <div className="min-h-dvh">
      <header className="border-b border-line bg-paper">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <Link to="/" className="num text-xl font-extrabold tracking-tight">
            Dayzero <span className="font-medium text-muted">Coach</span>
          </Link>
          <div className="flex items-center gap-1">
            {repo instanceof DemoRepository && (
              <Button
                variant="ghost"
                onClick={() => {
                  if (confirm('Reset all demo data? Anything you added in this browser will be replaced.')) {
                    ;(repo as DemoRepository).resetDemoData()
                    qc.invalidateQueries()
                  }
                }}
              >
                Reset demo data
              </Button>
            )}
            <Button variant="ghost" onClick={() => repo.signOut()}>
              Sign out
            </Button>
          </div>
        </div>
      </header>
      {repo.mode === 'demo' && (
        <p className="bg-cobalt-soft px-5 py-2 text-center text-sm">
          Demo mode. These clients are fake and everything is saved in this browser only.
        </p>
      )}
      <div className="mx-auto max-w-6xl px-5 py-6">
        <Outlet />
      </div>
    </div>
  )
}
