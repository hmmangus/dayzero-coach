import type { ClientTargets, DailyMetric, FoodEntry } from '../schemas'
import { caloriesFromMacros, dailyTotals, entryTotals, macroMismatch, targetsOn } from './nutrition'
import { buildWeeklySummaries, loggingStreak, mean, movingAverage } from './weekly'

const target = (over: Partial<ClientTargets> = {}): ClientTargets => ({
  id: 't1',
  clientId: 'c1',
  effectiveFrom: '2026-11-02',
  calories: 2000,
  proteinG: 150,
  carbsG: 200,
  fatG: 60,
  dailySteps: 8000,
  goalWeightLbs: 170,
  ...over,
})

let n = 0
const food = (date: string, calories: number, proteinG = 0, servings = 1): FoodEntry => ({
  id: `f${++n}`,
  clientId: 'c1',
  date,
  meal: 'lunch',
  name: 'x',
  calories,
  proteinG,
  carbsG: 0,
  fatG: 0,
  servings,
  createdAt: `${date}T12:00:00Z`,
})

const metric = (date: string, weightLbs: number | null, steps: number | null = null): DailyMetric => ({
  id: `m${date}`,
  clientId: 'c1',
  date,
  weightLbs,
  steps,
  note: null,
})

describe('nutrition helpers', () => {
  it('computes calories from macros with 4/4/9', () => {
    expect(caloriesFromMacros(30, 40, 10)).toBe(370)
  })

  it('flags a clear calorie/macro mismatch but not small gaps', () => {
    expect(macroMismatch(370, 30, 40, 10)).toBeNull()
    expect(macroMismatch(400, 30, 40, 10)).toBeNull() // 30 kcal off: fine
    expect(macroMismatch(800, 30, 40, 10)).toBe(370)
    expect(macroMismatch(500, 0, 0, 0)).toBeNull() // no macros entered
  })

  it('multiplies by servings', () => {
    expect(entryTotals(food('2026-11-02', 200, 20, 1.5))).toMatchObject({ calories: 300, proteinG: 30 })
  })

  it('totals each day separately', () => {
    const t = dailyTotals([food('2026-11-02', 500), food('2026-11-02', 300), food('2026-11-03', 100)])
    expect(t.get('2026-11-02')?.calories).toBe(800)
    expect(t.get('2026-11-03')?.calories).toBe(100)
    expect(t.has('2026-11-04')).toBe(false)
  })

  it('picks the target version in effect on a date', () => {
    const v1 = target({ id: 'v1', effectiveFrom: '2026-10-01', calories: 2200 })
    const v2 = target({ id: 'v2', effectiveFrom: '2026-11-05', calories: 1900 })
    expect(targetsOn([v2, v1], '2026-11-04')?.id).toBe('v1')
    expect(targetsOn([v2, v1], '2026-11-05')?.id).toBe('v2')
    expect(targetsOn([v2, v1], '2026-09-01')?.id).toBe('v1') // before first: earliest
    expect(targetsOn([], '2026-11-05')).toBeNull()
  })
})

describe('mean', () => {
  it('ignores nulls instead of treating them as zero', () => {
    expect(mean([2000, null, 1800, undefined])).toBe(1900)
    expect(mean([null, null])).toBeNull()
  })
})

describe('buildWeeklySummaries', () => {
  // Week of Mon Nov 2 – Sun Nov 8 2026, and the following week.
  const entries = [
    food('2026-11-02', 2000, 150),
    food('2026-11-03', 1500, 100), // under target
    food('2026-11-04', 2100, 160),
    food('2026-11-10', 2400, 140),
  ]
  const metrics = [
    metric('2026-11-02', 180, 9000),
    metric('2026-11-04', 179, 6000),
    metric('2026-11-09', 178, null),
    metric('2026-11-11', 177, 10000),
  ]
  const weeks = buildWeeklySummaries({ entries, metrics, targets: [target()], from: '2026-11-02', to: '2026-11-15' })

  it('splits into Monday-start weeks', () => {
    expect(weeks.map((w) => [w.weekStart, w.weekEnd])).toEqual([
      ['2026-11-02', '2026-11-08'],
      ['2026-11-09', '2026-11-15'],
    ])
    expect(weeks[0].days).toHaveLength(7)
  })

  it('averages only over logged days and reports how many', () => {
    expect(weeks[0].daysLogged).toBe(3)
    expect(weeks[0].avgCalories).toBeCloseTo((2000 + 1500 + 2100) / 3)
    expect(weeks[1].daysLogged).toBe(1)
    expect(weeks[1].avgCalories).toBe(2400)
  })

  it('computes adherence against targets', () => {
    // ±10% of 2000 → 1800..2200: days 1 and 3 hit, day 2 misses.
    expect(weeks[0].calorieAdherencePct).toBe(67)
    // protein floor 135g: 150 and 160 hit, 100 misses
    expect(weeks[0].proteinAdherencePct).toBe(67)
    // steps: 9000 hit, 6000 miss
    expect(weeks[0].stepAdherencePct).toBe(50)
  })

  it('tracks weekly average weight and week-over-week change', () => {
    expect(weeks[0].avgWeightLbs).toBe(179.5)
    expect(weeks[1].avgWeightLbs).toBe(177.5)
    expect(weeks[1].weightChangeLbs).toBe(-2)
    expect(weeks[0].weightChangeLbs).toBeNull()
  })

  it('returns nulls for an empty week instead of zeros', () => {
    const empty = buildWeeklySummaries({ entries: [], metrics: [], targets: [], from: '2026-11-02', to: '2026-11-08' })
    expect(empty[0]).toMatchObject({ daysLogged: 0, avgCalories: null, avgWeightLbs: null, calorieAdherencePct: null })
  })

  it('judges each day against the target in effect that day', () => {
    const v1 = target({ id: 'v1', effectiveFrom: '2026-11-01', calories: 2500 })
    const v2 = target({ id: 'v2', effectiveFrom: '2026-11-04', calories: 2000 })
    const w = buildWeeklySummaries({
      entries: [food('2026-11-03', 2500), food('2026-11-04', 2500)],
      metrics: [],
      targets: [v1, v2],
      from: '2026-11-02',
      to: '2026-11-08',
    })[0]
    expect(w.days[1].hitCalories).toBe(true) // 2500 vs 2500
    expect(w.days[2].hitCalories).toBe(false) // 2500 vs 2000
    expect(w.target?.id).toBe('v2')
  })

  it('clips a partial final week to the range end', () => {
    const w = buildWeeklySummaries({ entries: [], metrics: [], targets: [], from: '2026-11-02', to: '2026-11-04' })
    expect(w[0].days.map((d) => d.date)).toEqual(['2026-11-02', '2026-11-03', '2026-11-04'])
  })
})

describe('movingAverage', () => {
  it('averages the trailing 7 calendar days, skipping gaps', () => {
    const pts = [
      { date: '2026-11-01', value: 180 },
      { date: '2026-11-02', value: null },
      { date: '2026-11-03', value: 178 },
      { date: '2026-11-09', value: 170 },
    ]
    const ma = movingAverage(pts, 7)
    expect(ma[0].value).toBe(180)
    expect(ma[2].value).toBe(179)
    expect(ma[3].value).toBe(174) // Nov 3..9 window: 178 and 170
  })
})

describe('loggingStreak', () => {
  it('counts back from today', () => {
    expect(loggingStreak(['2026-11-05', '2026-11-06', '2026-11-07'], '2026-11-07')).toBe(3)
  })
  it("doesn't break the streak just because today isn't logged yet", () => {
    expect(loggingStreak(['2026-11-05', '2026-11-06'], '2026-11-07')).toBe(2)
  })
  it('is zero after a missed day', () => {
    expect(loggingStreak(['2026-11-04'], '2026-11-07')).toBe(0)
  })
})

describe('in-progress day', () => {
  it('shows today but leaves it out of averages and adherence', () => {
    const [w] = buildWeeklySummaries({
      entries: [food('2026-11-02', 2000, 150), food('2026-11-03', 600, 40)],
      metrics: [metric('2026-11-02', 180, 9000), metric('2026-11-03', 179, 2000)],
      targets: [target()],
      from: '2026-11-02',
      to: '2026-11-03',
      inProgressDate: '2026-11-03',
    })
    expect(w.days[1]).toMatchObject({ inProgress: true, hitCalories: null, hitSteps: null })
    expect(w.days[1].food?.calories).toBe(600) // still visible
    expect(w.daysLogged).toBe(1)
    expect(w.avgCalories).toBe(2000)
    expect(w.avgSteps).toBe(9000)
    expect(w.avgWeightLbs).toBe(179.5) // morning weigh-in counts
    expect(w.calorieAdherencePct).toBe(100)
  })
})
