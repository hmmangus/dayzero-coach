import type { ClientTargets, DailyMetric, FoodEntry } from '../schemas'
import { daysBetween, shiftIso, weekStartIso } from './dates'
import { dailyTotals, targetsOn, type Totals } from './nutrition'

export interface DaySummary {
  date: string
  food: Totals | null // null = nothing logged
  weightLbs: number | null
  steps: number | null
  target: ClientTargets | null
  hitCalories: boolean | null // within ±10% of target
  hitProtein: boolean | null // at least 90% of protein target
  hitSteps: boolean | null
  inProgress: boolean // today: shown, but not counted until the day is over
}

export interface WeekSummary {
  weekStart: string
  weekEnd: string
  days: DaySummary[]
  daysLogged: number // finished days with any food entry
  avgCalories: number | null
  avgProteinG: number | null
  avgCarbsG: number | null
  avgFatG: number | null
  avgSteps: number | null
  avgWeightLbs: number | null
  weightChangeLbs: number | null // vs previous week's average weight
  calorieAdherencePct: number | null
  proteinAdherencePct: number | null
  stepAdherencePct: number | null
  target: ClientTargets | null // in effect at the end of the week
}

const CALORIE_TOLERANCE = 0.1
const PROTEIN_FLOOR = 0.9

/** Mean of the non-null values. Unlogged days are excluded rather than counted as zero. */
export function mean(values: (number | null | undefined)[]): number | null {
  const v = values.filter((x): x is number => typeof x === 'number' && Number.isFinite(x))
  return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null
}

const pct = (flags: (boolean | null)[]) => {
  const known = flags.filter((f): f is boolean => f !== null)
  return known.length ? Math.round((known.filter(Boolean).length / known.length) * 100) : null
}

export function summarizeDay(
  date: string,
  food: Totals | null,
  metric: DailyMetric | undefined,
  targets: ClientTargets[],
  inProgress = false,
): DaySummary {
  const target = targetsOn(targets, date)
  const steps = metric?.steps ?? null
  const day: DaySummary = {
    date,
    food,
    weightLbs: metric?.weightLbs ?? null,
    steps,
    target,
    hitCalories:
      food && target && target.calories > 0
        ? Math.abs(food.calories - target.calories) <= target.calories * CALORIE_TOLERANCE
        : null,
    hitProtein: food && target && target.proteinG > 0 ? food.proteinG >= target.proteinG * PROTEIN_FLOOR : null,
    hitSteps: steps !== null && target && target.dailySteps > 0 ? steps >= target.dailySteps : null,
    inProgress,
  }
  // A half-finished day would read as a big calorie deficit, so it isn't judged yet.
  return inProgress ? { ...day, hitCalories: null, hitProtein: null, hitSteps: null } : day
}

/**
 * Rolls daily logs up into Monday–Sunday weeks covering [from, to].
 * Averages only use days that have data, and always report daysLogged
 * so a "great" average from 2 logged days is visible as such.
 * Pass `inProgressDate` (usually today) to show that day without counting
 * its partial food and steps in averages or adherence. Weight still counts:
 * the morning weigh-in is complete once it's logged.
 */
export function buildWeeklySummaries(input: {
  entries: FoodEntry[]
  metrics: DailyMetric[]
  targets: ClientTargets[]
  from: string
  to: string
  inProgressDate?: string
}): WeekSummary[] {
  const { entries, metrics, targets, from, to, inProgressDate } = input
  const totals = dailyTotals(entries)
  const metricByDay = new Map(metrics.map((m) => [m.date, m]))

  const weeks: WeekSummary[] = []
  for (let ws = weekStartIso(from); ws <= to; ws = shiftIso(ws, 7)) {
    const we = shiftIso(ws, 6)
    const days = daysBetween(ws, we)
      .filter((d) => d >= from && d <= to)
      .map((d) => summarizeDay(d, totals.get(d) ?? null, metricByDay.get(d), targets, d === inProgressDate))

    const finished = days.filter((d) => !d.inProgress)
    const logged = finished.filter((d) => d.food)
    const food = logged.map((d) => d.food as Totals)
    const avgCalories = mean(food.map((f) => f.calories))
    const avgProteinG = mean(food.map((f) => f.proteinG))
    const avgCarbsG = mean(food.map((f) => f.carbsG))
    const avgFatG = mean(food.map((f) => f.fatG))
    const avgSteps = mean(finished.map((d) => d.steps))
    const avgWeightLbs = mean(days.map((d) => d.weightLbs))

    weeks.push({
      weekStart: ws,
      weekEnd: we,
      days,
      daysLogged: logged.length,
      avgCalories,
      avgProteinG,
      avgCarbsG,
      avgFatG,
      avgSteps,
      avgWeightLbs,
      weightChangeLbs: null,
      calorieAdherencePct: pct(days.map((d) => d.hitCalories)),
      proteinAdherencePct: pct(days.map((d) => d.hitProtein)),
      stepAdherencePct: pct(days.map((d) => d.hitSteps)),
      target: targetsOn(targets, we < to ? we : to),
    })
  }

  // Week-over-week weight change uses weekly averages, which smooth out water-weight noise.
  for (let i = 1; i < weeks.length; i++) {
    const prev = weeks[i - 1].avgWeightLbs
    const cur = weeks[i].avgWeightLbs
    weeks[i].weightChangeLbs = prev !== null && cur !== null ? Math.round((cur - prev) * 10) / 10 : null
  }
  return weeks
}

/** Trailing moving average over the previous `window` calendar days that have a value. */
export function movingAverage(points: { date: string; value: number | null }[], window = 7) {
  return points.map((p, i) => {
    const start = shiftIso(p.date, -(window - 1))
    const slice = points.slice(Math.max(0, i - window * 2), i + 1).filter((q) => q.date >= start)
    return { date: p.date, value: mean(slice.map((q) => q.value)) }
  })
}

/** Consecutive logged days ending today (or yesterday, if today isn't logged yet). */
export function loggingStreak(loggedDates: Iterable<string>, today: string): number {
  const set = new Set(loggedDates)
  let day = set.has(today) ? today : shiftIso(today, -1)
  let streak = 0
  while (set.has(day)) {
    streak++
    day = shiftIso(day, -1)
  }
  return streak
}

/** Most recent date with a food entry, or null. */
export function lastLoggedDate(entries: FoodEntry[]): string | null {
  return entries.reduce<string | null>((max, e) => (!max || e.date > max ? e.date : max), null)
}
