import { Fragment, useMemo, useState, type FormEvent } from 'react'
import { Link, useParams } from 'react-router-dom'
import { repo } from '../../data'
import { Button, ErrorNote, Field, fmt, Select, Sheet, Spinner } from '../../components/ui'
import { WeekDetail } from '../../components/WeekDetail'
import { useClient, useFood, useMetrics, useSetTargets, useTargets, useUpdateClient } from '../../hooks/useData'
import { shiftIso, shortDay, todayIso, weekStartIso } from '../../lib/dates'
import { entryTotals, targetsOn } from '../../lib/nutrition'
import { buildWeeklySummaries, type WeekSummary } from '../../lib/weekly'
import { LABELS, STAGES, TargetsInputSchema, TIERS, type Client, type ClientTargets, type FoodEntry } from '../../schemas'
import { ProgressCharts } from './ProgressCharts'
import { parseTargetForm, TargetFields, targetsToForm } from './TargetFields'

const RANGES = [4, 8, 12] as const

export function ClientDetailPage() {
  const { id = '' } = useParams()
  const client = useClient(id)
  const [range, setRange] = useState<(typeof RANGES)[number]>(8)
  const today = todayIso()
  const from = shiftIso(weekStartIso(today), -7 * (range - 1))

  const food = useFood(id, from, today)
  const metrics = useMetrics(id, from, today)
  const targets = useTargets(id)
  const [editingTargets, setEditingTargets] = useState(false)
  const [openWeek, setOpenWeek] = useState<string | null>(null)

  const weeks = useMemo(
    () =>
      food.data && metrics.data && targets.data
        ? buildWeeklySummaries({ entries: food.data, metrics: metrics.data, targets: targets.data, from, to: today, inProgressDate: today })
        : null,
    [food.data, metrics.data, targets.data, from, today],
  )

  if (client.isLoading) return <Spinner />
  if (client.error) return <ErrorNote error={client.error} />
  if (!client.data)
    return (
      <p>
        That client doesn't exist. <Link to="/" className="font-semibold text-cobalt">Back to clients</Link>
      </p>
    )

  const c = client.data
  const current = targetsOn(targets.data ?? [], today)
  const newestFirst = [...(weeks ?? [])].reverse()

  return (
    <div>
      <Link to="/" className="text-sm font-semibold text-muted hover:text-ink">
        ‹ Clients
      </Link>
      <div className="mt-2 grid gap-4 lg:grid-cols-[1fr_340px]">
        <div>
          <h1 className="num text-4xl font-extrabold tracking-tight">{c.name}</h1>
          <p className="mt-1 text-muted">
            {c.email}. {LABELS.goal[c.goal]}, {LABELS.tier[c.programTier]}, from {LABELS.leadSource[c.leadSource].toLowerCase()}
            {c.startDate && `. Started ${shortDay(c.startDate)}`}.
          </p>
          {!c.profileId && repo.mode === 'supabase' && (
            <p className="mt-3 rounded-xl bg-carbs/15 px-4 py-2 text-sm">
              {c.name.split(' ')[0]} hasn't signed in yet. Send them the app link and tell them to sign in with {c.email}.
            </p>
          )}
        </div>
        <ClientMeta client={c} />
      </div>

      <section className="mt-6 rounded-3xl bg-surface p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-semibold">Daily targets</h2>
            {current ? (
              <p className="text-muted">
                <span className="num font-bold text-ink">{fmt(current.calories)}</span> cal,{' '}
                <span className="font-semibold text-protein">{fmt(current.proteinG)}g</span> protein,{' '}
                <span className="font-semibold text-carbs">{fmt(current.carbsG)}g</span> carbs,{' '}
                <span className="font-semibold text-fat">{fmt(current.fatG)}g</span> fat, {fmt(current.dailySteps)} steps
                {current.goalWeightLbs !== null && `, goal ${fmt(current.goalWeightLbs, 1)} lbs`}
              </p>
            ) : (
              <p className="text-muted">No targets yet.</p>
            )}
          </div>
          <Button variant="secondary" onClick={() => setEditingTargets(true)}>
            Change targets
          </Button>
        </div>
      </section>

      <div className="mt-8 flex flex-wrap items-center justify-between gap-3">
        <h2 className="num text-2xl font-bold">Weekly averages</h2>
        <div className="flex gap-1 rounded-full bg-surface p-1">
          {RANGES.map((r) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              aria-pressed={range === r}
              className={`rounded-full px-3 py-1.5 text-sm font-semibold ${range === r ? 'bg-ink text-white' : 'text-muted'}`}
            >
              {r} weeks
            </button>
          ))}
        </div>
      </div>

      {food.error ? (
        <ErrorNote error={food.error} />
      ) : !weeks ? (
        <Spinner />
      ) : (
        <>
          <div className="mt-3 overflow-x-auto rounded-3xl bg-surface">
            <table className="w-full min-w-[820px] text-left text-[15px]">
              <thead className="border-b border-line text-sm text-muted">
                <tr>
                  <th className="px-5 py-3 font-medium">Week of</th>
                  <th className="px-3 py-3 font-medium">Days logged</th>
                  <th className="px-3 py-3 font-medium">Calories</th>
                  <th className="px-3 py-3 font-medium">Protein</th>
                  <th className="px-3 py-3 font-medium">Carbs</th>
                  <th className="px-3 py-3 font-medium">Fat</th>
                  <th className="px-3 py-3 font-medium">Steps</th>
                  <th className="px-3 py-3 font-medium">Avg weight</th>
                  <th className="px-5 py-3 font-medium">On target</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {newestFirst.map((w) => (
                  <Fragment key={w.weekStart}>
                    <WeekRow week={w} open={openWeek === w.weekStart} onToggle={() => setOpenWeek(openWeek === w.weekStart ? null : w.weekStart)} />
                    {openWeek === w.weekStart && (
                      <tr>
                        <td colSpan={9} className="bg-paper/50 px-5 py-5">
                          <WeekDetail week={w} />
                          <DayFoods entries={(food.data ?? []).filter((e) => e.date >= w.weekStart && e.date <= w.weekEnd)} />
                        </td>
                      </tr>
                    )}
                  </Fragment>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-2 text-sm text-muted">
            Averages use logged days only, so a skipped day doesn't count as zero. Click a week to see each day and every food.
          </p>

          <div className="mt-8">
            <ProgressCharts weeks={weeks} goalWeight={current?.goalWeightLbs ?? null} />
          </div>
        </>
      )}

      {editingTargets && (
        <TargetsSheet clientId={c.id} current={current} history={targets.data ?? []} onClose={() => setEditingTargets(false)} />
      )}
    </div>
  )
}

function WeekRow({ week: w, open, onToggle }: { week: WeekSummary; open: boolean; onToggle: () => void }) {
  const t = w.target
  const finished = w.days.filter((d) => !d.inProgress).length
  const cell = (v: number | null, target: number | undefined, unit = '') => (
    <td className="px-3 py-3">
      <span className="num font-semibold">{v === null ? '—' : `${fmt(v)}${unit}`}</span>
      {v !== null && target !== undefined && <span className="ml-1 text-sm text-muted">/ {fmt(target)}</span>}
    </td>
  )
  return (
    <tr className="cursor-pointer hover:bg-paper/60" onClick={onToggle}>
      <td className="px-5 py-3">
        <button className="font-semibold" aria-expanded={open}>
          <span className="mr-2 inline-block w-3 text-muted">{open ? '▾' : '▸'}</span>
          {shortDay(w.weekStart)}
        </button>
      </td>
      <td className={`px-3 py-3 num font-semibold ${w.daysLogged < Math.min(4, finished) ? 'text-warn' : ''}`}>
        {w.daysLogged} / {finished}
      </td>
      {cell(w.avgCalories, t?.calories)}
      {cell(w.avgProteinG, t?.proteinG, 'g')}
      {cell(w.avgCarbsG, t?.carbsG, 'g')}
      {cell(w.avgFatG, t?.fatG, 'g')}
      {cell(w.avgSteps, t?.dailySteps)}
      <td className="px-3 py-3">
        <span className="num font-semibold">{w.avgWeightLbs === null ? '—' : fmt(w.avgWeightLbs, 1)}</span>
        {w.weightChangeLbs !== null && (
          <span className="ml-1.5 text-sm text-muted">
            ({w.weightChangeLbs > 0 ? '+' : ''}
            {fmt(w.weightChangeLbs, 1)})
          </span>
        )}
      </td>
      <td className="px-5 py-3 text-sm">
        {w.calorieAdherencePct === null ? (
          '—'
        ) : (
          <>
            <b className="num text-base">{w.calorieAdherencePct}%</b> cal, <b className="num text-base">{w.proteinAdherencePct ?? 0}%</b> protein
          </>
        )}
      </td>
    </tr>
  )
}

function DayFoods({ entries }: { entries: FoodEntry[] }) {
  const byDay = new Map<string, FoodEntry[]>()
  for (const e of entries) byDay.set(e.date, [...(byDay.get(e.date) ?? []), e])
  const days = [...byDay.keys()].sort()
  if (!days.length) return null
  return (
    <details className="mt-5">
      <summary className="cursor-pointer text-sm font-semibold text-cobalt">Show every food logged this week</summary>
      <div className="mt-3 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {days.map((d) => (
          <div key={d}>
            <p className="font-semibold">{shortDay(d)}</p>
            <ul className="mt-1 space-y-0.5 text-sm">
              {byDay.get(d)!.map((e) => (
                <li key={e.id} className="flex justify-between gap-3">
                  <span className="truncate text-muted">
                    {LABELS.meal[e.meal]}: <span className="text-ink">{e.name}</span>
                    {e.servings !== 1 && ` × ${e.servings}`}
                  </span>
                  <span className="num shrink-0 font-semibold">{fmt(entryTotals(e).calories)}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </details>
  )
}

function ClientMeta({ client: c }: { client: Client }) {
  const update = useUpdateClient(c.id)
  const [notes, setNotes] = useState(c.notes)
  return (
    <div className="space-y-3 rounded-3xl bg-surface p-5">
      <div className="grid grid-cols-2 gap-3">
        <Select label="Stage" value={c.stage} options={STAGES} labels={LABELS.stage} onChange={(stage) => update.mutate({ stage })} />
        <Select label="Program" value={c.programTier} options={TIERS} labels={LABELS.tier} onChange={(programTier) => update.mutate({ programTier })} />
      </div>
      <Field
        label="Next check-in"
        type="date"
        value={c.nextCheckInDate ?? ''}
        onChange={(e) => update.mutate({ nextCheckInDate: e.target.value || null })}
      />
      <label className="block">
        <span className="mb-1 block text-sm font-medium text-muted">Coach notes</span>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          onBlur={() => notes !== c.notes && update.mutate({ notes })}
          rows={3}
          className="w-full rounded-xl border border-line bg-surface px-3 py-2 text-[15px] outline-none focus:border-cobalt"
        />
      </label>
      {update.error ? <ErrorNote error={update.error} /> : null}
    </div>
  )
}

function TargetsSheet({
  clientId,
  current,
  history,
  onClose,
}: {
  clientId: string
  current: ClientTargets | null
  history: ClientTargets[]
  onClose: () => void
}) {
  const save = useSetTargets(clientId)
  const [form, setForm] = useState(
    targetsToForm(current ?? { calories: 2000, proteinG: 150, carbsG: 200, fatG: 65, dailySteps: 8000, goalWeightLbs: null }),
  )
  const [from, setFrom] = useState(todayIso())
  const [errors, setErrors] = useState<Record<string, string>>({})

  function submit(e: FormEvent) {
    e.preventDefault()
    const parsed = TargetsInputSchema.safeParse(parseTargetForm(form))
    if (!parsed.success) {
      const errs: Record<string, string> = {}
      for (const i of parsed.error.issues) errs[`t.${String(i.path[0])}`] = 'Enter a number'
      setErrors(errs)
      return
    }
    save.mutate({ targets: parsed.data, effectiveFrom: from }, { onSuccess: onClose })
  }

  return (
    <Sheet title="Change targets" onClose={onClose}>
      <form onSubmit={submit} className="space-y-4">
        <TargetFields value={form} onChange={setForm} errors={errors} />
        <Field
          label="Starts on"
          type="date"
          value={from}
          onChange={(e) => setFrom(e.target.value)}
          hint="Earlier weeks keep being judged against the targets they had at the time."
        />
        {save.error ? <ErrorNote error={save.error} /> : null}
        <Button className="w-full" disabled={save.isPending}>
          {save.isPending ? 'Saving…' : 'Save targets'}
        </Button>
        {history.length > 0 && (
          <div>
            <p className="text-sm font-semibold text-muted">History</p>
            <ul className="mt-1 space-y-1 text-sm">
              {[...history].reverse().map((h) => (
                <li key={h.id}>
                  From {shortDay(h.effectiveFrom)}: {fmt(h.calories)} cal, {fmt(h.proteinG)}p / {fmt(h.carbsG)}c / {fmt(h.fatG)}f,{' '}
                  {fmt(h.dailySteps)} steps
                </li>
              ))}
            </ul>
          </div>
        )}
      </form>
    </Sheet>
  )
}
