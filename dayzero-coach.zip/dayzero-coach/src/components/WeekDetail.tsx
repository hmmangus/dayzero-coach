import { Bar, BarChart, CartesianGrid, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { format } from 'date-fns'
import { fromIso } from '../lib/dates'
import type { WeekSummary } from '../lib/weekly'
import { fmt } from './ui'

/** One week: day strip, weekly averages vs targets, and daily calories. Shared by client and coach. */
export function WeekDetail({ week }: { week: WeekSummary }) {
  const t = week.target
  const hasToday = week.days.some((d) => d.inProgress)
  const finishedDays = week.days.length - (hasToday ? 1 : 0)
  const stats: { label: string; value: string; sub: string }[] = [
    { label: 'Avg calories', value: fmt(week.avgCalories), sub: `target ${fmt(t?.calories)}` },
    { label: 'Avg protein', value: week.avgProteinG === null ? '—' : `${fmt(week.avgProteinG)}g`, sub: `target ${fmt(t?.proteinG)}g` },
    { label: 'Avg carbs', value: week.avgCarbsG === null ? '—' : `${fmt(week.avgCarbsG)}g`, sub: `target ${fmt(t?.carbsG)}g` },
    { label: 'Avg fat', value: week.avgFatG === null ? '—' : `${fmt(week.avgFatG)}g`, sub: `target ${fmt(t?.fatG)}g` },
    { label: 'Avg steps', value: fmt(week.avgSteps), sub: `target ${fmt(t?.dailySteps)}` },
    {
      label: 'Avg weight',
      value: week.avgWeightLbs === null ? '—' : `${fmt(week.avgWeightLbs, 1)}`,
      sub:
        week.weightChangeLbs === null
          ? 'lbs'
          : `${week.weightChangeLbs > 0 ? '+' : ''}${fmt(week.weightChangeLbs, 1)} lbs vs last week`,
    },
  ]

  const chart = week.days.map((d) => ({
    day: format(fromIso(d.date), 'EEE'),
    calories: d.food ? Math.round(d.food.calories) : 0,
    logged: !!d.food,
  }))

  return (
    <div>
      <ol className="grid grid-cols-7 gap-1.5" aria-label="Days this week">
        {week.days.map((d) => {
          const state = d.inProgress ? 'today' : !d.food ? 'none' : d.hitCalories ? 'hit' : 'miss'
          return (
            <li
              key={d.date}
              className={`rounded-xl py-2 text-center ${
                state === 'hit'
                  ? 'bg-cobalt text-white'
                  : state === 'miss'
                    ? 'bg-cobalt-soft text-ink'
                    : state === 'today'
                      ? 'border-2 border-ink text-ink'
                      : 'border border-dashed border-line text-muted'
              }`}
              title={state === 'today' ? 'Today, counted tomorrow' : state === 'hit' ? 'Logged, on target' : state === 'miss' ? 'Logged, off target' : 'Not logged'}
            >
              <span className="block text-xs font-medium">{format(fromIso(d.date), 'EEEEE')}</span>
              <span className="num block text-base font-bold">{format(fromIso(d.date), 'd')}</span>
            </li>
          )
        })}
      </ol>
      <p className="mt-2 text-sm text-muted">
        Logged <b className="text-ink">{week.daysLogged}</b> of {finishedDays} finished days. Averages count logged days only
        {hasToday ? ', and today is added once it ends' : ''}.
        {week.calorieAdherencePct !== null && ` On calorie target ${week.calorieAdherencePct}% of logged days.`}
      </p>

      <dl className="mt-5 grid grid-cols-2 gap-x-4 gap-y-4 sm:grid-cols-3">
        {stats.map((s) => (
          <div key={s.label}>
            <dt className="text-sm text-muted">{s.label}</dt>
            <dd className="num text-2xl font-bold">{s.value}</dd>
            <dd className="text-sm text-muted">{s.sub}</dd>
          </div>
        ))}
      </dl>

      <div className="mt-6 h-48" aria-label="Daily calories chart">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chart} margin={{ top: 8, right: 8, bottom: 0, left: -18 }}>
            <CartesianGrid vertical={false} stroke="var(--color-line)" />
            <XAxis dataKey="day" tickLine={false} axisLine={false} fontSize={12} />
            <YAxis tickLine={false} axisLine={false} fontSize={12} />
            <Tooltip
              cursor={{ fill: 'rgba(22,27,38,0.04)' }}
              formatter={(v) => [`${Number(v).toLocaleString()} cal`, 'Eaten']}
            />
            {t && <ReferenceLine y={t.calories} stroke="var(--color-ink)" strokeDasharray="4 4" />}
            <Bar dataKey="calories" fill="var(--color-cobalt)" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
