import { NavLink, Outlet, useOutletContext } from 'react-router-dom'
import { repo } from '../../data'
import { useMyClient } from '../../hooks/useData'
import { Button, ErrorNote, Spinner } from '../../components/ui'
import type { Client } from '../../schemas'

export const useCurrentClient = () => useOutletContext<{ client: Client }>().client

const tab = ({ isActive }: { isActive: boolean }) =>
  `flex-1 py-3 text-center text-[15px] font-semibold ${isActive ? 'text-ink' : 'text-muted'}`

export function ClientShell() {
  const { data: client, isLoading, error } = useMyClient()

  if (isLoading) return <Spinner />
  if (error) return <div className="p-6"><ErrorNote error={error} /></div>
  if (!client)
    return (
      <main className="mx-auto max-w-sm px-6 py-20">
        <h1 className="num text-3xl font-bold">You're signed in.</h1>
        <p className="mt-3 text-muted">
          Your coach hasn't added this email yet. Ask them to add you, then refresh this page.
        </p>
        <Button variant="secondary" className="mt-8" onClick={() => repo.signOut()}>
          Sign out
        </Button>
      </main>
    )

  return (
    <div className="mx-auto min-h-dvh max-w-md pb-24">
      <Outlet context={{ client }} />
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-paper/95 pb-[env(safe-area-inset-bottom)] backdrop-blur">
        <div className="mx-auto flex max-w-md">
          <NavLink to="/" end className={tab}>
            Today
          </NavLink>
          <NavLink to="/week" className={tab}>
            Week
          </NavLink>
          <button className="flex-1 py-3 text-center text-[15px] font-semibold text-muted" onClick={() => repo.signOut()}>
            Sign out
          </button>
        </div>
      </nav>
    </div>
  )
}
