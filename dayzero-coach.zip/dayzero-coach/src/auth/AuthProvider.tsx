import { useQuery, useQueryClient } from '@tanstack/react-query'
import { createContext, useContext, useEffect, type ReactNode } from 'react'
import { repo, type Viewer } from '../data'

interface AuthState {
  viewer: Viewer | null
  loading: boolean
}

const AuthContext = createContext<AuthState>({ viewer: null, loading: true })

export function AuthProvider({ children }: { children: ReactNode }) {
  const qc = useQueryClient()
  const { data, isLoading } = useQuery({ queryKey: ['viewer'], queryFn: () => repo.getViewer() })

  useEffect(
    () =>
      repo.onAuthChange(() => {
        // Different user → nothing cached for the previous one should leak through.
        qc.removeQueries({ predicate: (q) => q.queryKey[0] !== 'viewer' })
        qc.invalidateQueries({ queryKey: ['viewer'] })
      }),
    [qc],
  )

  return <AuthContext.Provider value={{ viewer: data ?? null, loading: isLoading }}>{children}</AuthContext.Provider>
}

export const useAuth = () => useContext(AuthContext)
