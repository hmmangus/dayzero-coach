import { Navigate, Route, Routes } from 'react-router-dom'
import { useAuth } from './auth/AuthProvider'
import { Spinner } from './components/ui'
import { LoginPage } from './features/auth/LoginPage'
import { ClientShell } from './features/client/ClientShell'
import { TodayPage } from './features/client/TodayPage'
import { WeekPage } from './features/client/WeekPage'
import { ClientDetailPage } from './features/coach/ClientDetailPage'
import { ClientsPage } from './features/coach/ClientsPage'
import { CoachShell } from './features/coach/CoachShell'

export default function App() {
  const { viewer, loading } = useAuth()
  if (loading) return <Spinner />
  if (!viewer) return <LoginPage />

  // Same URL, different app: the role on the signed-in profile decides which one you get.
  return viewer.role === 'coach' ? (
    <Routes>
      <Route element={<CoachShell />}>
        <Route index element={<ClientsPage />} />
        <Route path="clients/:id" element={<ClientDetailPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  ) : (
    <Routes>
      <Route element={<ClientShell />}>
        <Route index element={<TodayPage />} />
        <Route path="week" element={<WeekPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  )
}
