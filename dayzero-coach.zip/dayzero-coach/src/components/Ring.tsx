import type { ReactNode } from 'react'

/** Circular progress. Goes past 100% by wrapping in a darker tone so overages are visible. */
export function Ring({
  value,
  max,
  size = 220,
  stroke = 18,
  color = 'var(--color-cobalt)',
  track = 'var(--color-cobalt-soft)',
  children,
  label,
}: {
  value: number
  max: number
  size?: number
  stroke?: number
  color?: string
  track?: string
  children?: ReactNode
  label: string
}) {
  const r = (size - stroke) / 2
  const c = 2 * Math.PI * r
  const ratio = max > 0 ? value / max : 0
  const main = Math.min(ratio, 1)
  const over = ratio > 1 ? Math.min(ratio - 1, 1) : 0
  return (
    <div className="relative inline-grid place-items-center" style={{ width: size, height: size }}>
      <svg
        width={size}
        height={size}
        viewBox={`0 0 ${size} ${size}`}
        className="-rotate-90"
        role="img"
        aria-label={`${label}: ${Math.round(ratio * 100)}%`}
      >
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={track} strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - main)}
          style={{ transition: 'stroke-dashoffset 500ms ease' }}
        />
        {over > 0 && (
          <circle
            cx={size / 2}
            cy={size / 2}
            r={r}
            fill="none"
            stroke="var(--color-warn)"
            strokeWidth={stroke}
            strokeLinecap="round"
            strokeDasharray={c}
            strokeDashoffset={c * (1 - over)}
          />
        )}
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">{children}</div>
    </div>
  )
}

/** Thin horizontal bar used for macros. */
export function MacroBar({
  label,
  value,
  target,
  color,
}: {
  label: string
  value: number
  target: number
  color: string
}) {
  const ratio = target > 0 ? Math.min(value / target, 1) : 0
  return (
    <div>
      <div className="flex items-baseline justify-between">
        <span className="text-sm font-medium text-muted">{label}</span>
        <span className="text-sm text-muted">
          <span className="num text-lg font-bold text-ink">{Math.round(value)}</span> / {Math.round(target)}g
        </span>
      </div>
      <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-ink/8">
        <div
          className="h-full rounded-full"
          style={{ width: `${ratio * 100}%`, background: color, transition: 'width 500ms ease' }}
        />
      </div>
    </div>
  )
}
