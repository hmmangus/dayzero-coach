import {
  Bar,
  BarChart,
  CartesianGrid,
  ComposedChart,
  Legend,
  Line,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { shortDay } from '../../lib/dates'
import { movingAverage, type WeekSummary } from '../../lib/weekly'
import type { ReactElement } from 'react'

const axis = { tickLine: false, axisLine: false, fontSize: 12 } as const

function ChartCard({ title, sub, children }: { title: string; sub: string; children: ReactElement }) {
  return (
    <section className="rounded-3xl bg-surface p-5">
      <h3 className="font-semibold">{title}</h3>
      <p className="text-sm text-muted">{sub}</p>
      <div className="mt-3 h-56">
        <ResponsiveContainer width="100%" height="100%">
          {children}
        </ResponsiveContainer>
      </div>
    </section>
  )
}

export function ProgressCharts({ weeks, goalWeight }: { weeks: WeekSummary[]; goalWeight: number | null }) {
  const days = weeks.flatMap((w) => w.days)
  const ma = movingAverage(days.map((d) => ({ date: d.date, value: d.weightLbs })))
  const weight = days.map((d, i) => ({
    day: shortDay(d.date),
    weight: d.weightLbs,
    avg: ma[i].value === null ? null : Math.round(ma[i].value! * 10) / 10,
  }))

  const weekly = weeks.map((w) => ({
    week: shortDay(w.weekStart),
    calories: w.avgCalories === null ? null : Math.round(w.avgCalories),
    target: w.target?.calories ?? null,
    protein: w.avgProteinG === null ? null : Math.round(w.avgProteinG * 4),
    carbs: w.avgCarbsG === null ? null : Math.round(w.avgCarbsG * 4),
    fat: w.avgFatG === null ? null : Math.round(w.avgFatG * 9),
    steps: w.avgSteps === null ? null : Math.round(w.avgSteps),
    stepTarget: w.target?.dailySteps ?? null,
  }))

  const weights = days.map((d) => d.weightLbs).filter((x): x is number => x !== null)
  const lo = Math.floor(Math.min(...weights, goalWeight ?? Infinity) - 2)
  const hi = Math.ceil(Math.max(...weights, goalWeight ?? -Infinity) + 2)

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <ChartCard title="Weight" sub="Daily weigh-ins with the 7-day average. Dashed line is the goal.">
        <ComposedChart data={weight} margin={{ top: 8, right: 8, bottom: 0, left: -12 }}>
          <CartesianGrid vertical={false} stroke="var(--color-line)" />
          <XAxis dataKey="day" {...axis} minTickGap={28} />
          <YAxis {...axis} domain={weights.length ? [lo, hi] : ['auto', 'auto']} />
          <Tooltip />
          {goalWeight !== null && <ReferenceLine y={goalWeight} stroke="var(--color-good)" strokeDasharray="5 5" />}
          <Line dataKey="weight" name="Weigh-in" stroke="none" dot={{ r: 3, fill: 'var(--color-muted)', fillOpacity: 0.45, stroke: 'none' }} activeDot={{ r: 4 }} isAnimationActive={false} />
          <Line dataKey="avg" name="7-day avg" stroke="var(--color-ink)" strokeWidth={2.5} dot={false} connectNulls />
        </ComposedChart>
      </ChartCard>

      <ChartCard title="Average calories per week" sub="Bars are the weekly average on logged days. Line is the target.">
        <ComposedChart data={weekly} margin={{ top: 8, right: 8, bottom: 0, left: -12 }}>
          <CartesianGrid vertical={false} stroke="var(--color-line)" />
          <XAxis dataKey="week" {...axis} />
          <YAxis {...axis} />
          <Tooltip />
          <Bar dataKey="calories" name="Avg calories" fill="var(--color-cobalt)" radius={[6, 6, 0, 0]} />
          <Line dataKey="target" name="Target" stroke="var(--color-ink)" strokeDasharray="4 4" dot={false} type="stepAfter" />
        </ComposedChart>
      </ChartCard>

      <ChartCard title="Where the calories came from" sub="Weekly average calories from protein, carbs, and fat.">
        <BarChart data={weekly} margin={{ top: 8, right: 8, bottom: 0, left: -12 }}>
          <CartesianGrid vertical={false} stroke="var(--color-line)" />
          <XAxis dataKey="week" {...axis} />
          <YAxis {...axis} />
          <Tooltip />
          <Legend iconType="circle" wrapperStyle={{ fontSize: 13 }} />
          <Bar dataKey="protein" name="Protein" stackId="m" fill="var(--color-protein)" />
          <Bar dataKey="carbs" name="Carbs" stackId="m" fill="var(--color-carbs)" />
          <Bar dataKey="fat" name="Fat" stackId="m" fill="var(--color-fat)" radius={[6, 6, 0, 0]} />
        </BarChart>
      </ChartCard>

      <ChartCard title="Average steps per week" sub="Weekly average of days with steps logged. Line is the target.">
        <ComposedChart data={weekly} margin={{ top: 8, right: 8, bottom: 0, left: -6 }}>
          <CartesianGrid vertical={false} stroke="var(--color-line)" />
          <XAxis dataKey="week" {...axis} />
          <YAxis {...axis} />
          <Tooltip />
          <Bar dataKey="steps" name="Avg steps" fill="var(--color-fat)" radius={[6, 6, 0, 0]} />
          <Line dataKey="stepTarget" name="Target" stroke="var(--color-ink)" strokeDasharray="4 4" dot={false} type="stepAfter" />
        </ComposedChart>
      </ChartCard>
    </div>
  )
}
