-- Dayzero Coach: initial schema
-- Run this once in Supabase → SQL Editor (or `supabase db push`).

-- ============================================================
-- Profiles: one per auth user. Role decides coach vs client.
-- ============================================================
create table public.profiles (
  id          uuid primary key references auth.users (id) on delete cascade,
  email       text not null unique,
  role        text not null default 'client' check (role in ('coach', 'client')),
  created_at  timestamptz not null default now()
);

-- ============================================================
-- Clients: created by the coach. profile_id is filled in
-- automatically when the client first signs in with that email.
-- ============================================================
create table public.clients (
  id                  uuid primary key default gen_random_uuid(),
  profile_id          uuid unique references public.profiles (id) on delete set null,
  name                text not null,
  email               text not null unique check (email = lower(email)),
  lead_source         text not null check (lead_source in ('referral', 'social', 'gym', 'email_list')),
  stage               text not null default 'lead'
                      check (stage in ('lead', 'consult', 'beta', 'active', 'paused', 'churned')),
  program_tier        text not null default 'tier_1' check (program_tier in ('beta', 'tier_1', 'tier_2', 'tier_3')),
  goal                text not null default 'fat_loss'
                      check (goal in ('fat_loss', 'muscle_gain', 'recomp', 'maintenance')),
  start_date          date,
  next_check_in_date  date,
  notes               text not null default '',
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

-- Targets are versioned: a new row applies from effective_from onward,
-- so past weeks keep being judged against the targets they had then.
create table public.client_targets (
  id               uuid primary key default gen_random_uuid(),
  client_id        uuid not null references public.clients (id) on delete cascade,
  effective_from   date not null,
  calories         numeric not null check (calories >= 0),
  protein_g        numeric not null check (protein_g >= 0),
  carbs_g          numeric not null check (carbs_g >= 0),
  fat_g            numeric not null check (fat_g >= 0),
  daily_steps      integer not null check (daily_steps >= 0),
  goal_weight_lbs  numeric check (goal_weight_lbs >= 0),
  unique (client_id, effective_from)
);

create table public.food_entries (
  id          uuid primary key default gen_random_uuid(),
  client_id   uuid not null references public.clients (id) on delete cascade,
  date        date not null,
  meal        text not null check (meal in ('breakfast', 'lunch', 'dinner', 'snack')),
  name        text not null,
  calories    numeric not null check (calories >= 0),   -- per serving
  protein_g   numeric not null default 0 check (protein_g >= 0),
  carbs_g     numeric not null default 0 check (carbs_g >= 0),
  fat_g       numeric not null default 0 check (fat_g >= 0),
  servings    numeric not null default 1 check (servings > 0),
  created_at  timestamptz not null default now()
);
create index food_entries_client_date on public.food_entries (client_id, date);

create table public.saved_foods (
  id          uuid primary key default gen_random_uuid(),
  client_id   uuid not null references public.clients (id) on delete cascade,
  name        text not null,
  calories    numeric not null check (calories >= 0),
  protein_g   numeric not null default 0 check (protein_g >= 0),
  carbs_g     numeric not null default 0 check (carbs_g >= 0),
  fat_g       numeric not null default 0 check (fat_g >= 0)
);

create table public.daily_metrics (
  id          uuid primary key default gen_random_uuid(),
  client_id   uuid not null references public.clients (id) on delete cascade,
  date        date not null,
  weight_lbs  numeric check (weight_lbs > 0),
  steps       integer check (steps >= 0),
  note        text,
  unique (client_id, date)
);

-- ============================================================
-- Triggers
-- ============================================================

-- New auth user → profile, and link any client record with the same email.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email) values (new.id, lower(new.email))
  on conflict (id) do nothing;
  update public.clients set profile_id = new.id
   where email = lower(new.email) and profile_id is null;
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Coach adds a client whose account already exists → link it right away.
create or replace function public.link_client_profile()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  new.email := lower(new.email);
  if new.profile_id is null then
    select id into new.profile_id from public.profiles where email = new.email;
  end if;
  new.updated_at := now();
  return new;
end $$;

create trigger clients_link_profile
  before insert or update of email on public.clients
  for each row execute function public.link_client_profile();

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at := now(); return new; end $$;

create trigger clients_touch before update on public.clients
  for each row execute function public.touch_updated_at();

-- ============================================================
-- Row Level Security
-- Coach: full access to everything.
-- Client: read own client record + targets; read/write own logs.
-- Helper functions are SECURITY DEFINER so policies don't recurse.
-- ============================================================
create or replace function public.is_coach()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'coach')
$$;

create or replace function public.my_client_id()
returns uuid language sql stable security definer set search_path = public as $$
  select id from public.clients where profile_id = auth.uid()
$$;

alter table public.profiles       enable row level security;
alter table public.clients        enable row level security;
alter table public.client_targets enable row level security;
alter table public.food_entries   enable row level security;
alter table public.saved_foods    enable row level security;
alter table public.daily_metrics  enable row level security;

-- profiles: read your own (coach reads all). No insert/update policies:
-- only the trigger creates rows, so nobody can promote themselves to coach.
create policy "profiles: read own or coach" on public.profiles
  for select using (id = auth.uid() or public.is_coach());

create policy "clients: coach all" on public.clients
  for all using (public.is_coach()) with check (public.is_coach());
create policy "clients: read own" on public.clients
  for select using (profile_id = auth.uid());

create policy "targets: coach all" on public.client_targets
  for all using (public.is_coach()) with check (public.is_coach());
create policy "targets: read own" on public.client_targets
  for select using (client_id = public.my_client_id());

create policy "food: coach all" on public.food_entries
  for all using (public.is_coach()) with check (public.is_coach());
create policy "food: own" on public.food_entries
  for all using (client_id = public.my_client_id()) with check (client_id = public.my_client_id());

create policy "saved: coach all" on public.saved_foods
  for all using (public.is_coach()) with check (public.is_coach());
create policy "saved: own" on public.saved_foods
  for all using (client_id = public.my_client_id()) with check (client_id = public.my_client_id());

create policy "metrics: coach all" on public.daily_metrics
  for all using (public.is_coach()) with check (public.is_coach());
create policy "metrics: own" on public.daily_metrics
  for all using (client_id = public.my_client_id()) with check (client_id = public.my_client_id());
