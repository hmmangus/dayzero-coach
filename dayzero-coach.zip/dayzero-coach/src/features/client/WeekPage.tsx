import { useMemo } from 'react'
import { useSearchParams } from 'react-router-dom'
import { ErrorNote, Spinner } from '../../components/ui'
import { WeekDetail } from '../../components/WeekDetail'
import { useFood, useMetrics, useTargets } from '../../hooks/useData'
import { shiftIso, shortDay, todayIso, weekStartIso } from '../../lib/dates'
import { buildWeeklySummaries } from '../../lib/weekly'
import { useCurrentClient } from './ClientShell'

export function WeekPage() {
  const client = useCurrentClient()
  const [params, setParams] = useSearchParams()
  const today = todayIso()
  const thisWeek = weekStartIso(today)
  const ws = params.get('w') && params.get('w')! <= thisWeek ? weekStartIso(params.get('w')!) : thisWeek
  const prevWs = shiftIso(ws, -7)
  const end = ws === thisWeek ? today : shiftIso(ws, 6)

  // Load the previous week too, so week-over-week weight change works.
  const food = useFood(client.id, prevWs, end)
  const metrics = useMetrics(client.id, prevWs, end)
  const targets = useTargets(client.id)

  const week = useMemo(() => {
    if (!food.data || !metrics.data || !targets.data) return null
    return buildWeeklySummaries({ entries: food.data, metrics: metrics.data, targets: targets.data, from: prevWs, to: end, inProgressDate: today }).at(-1)!
  }, [food.data, metrics.data, targets.data, prevWs, end, today])

  const go = (w: string) => setParams(w === thisWeek ? {} : { w })

  return (
    <main className="px-5 pt-[max(1rem,env(safe-area-inset-top))]">
      <header className="flex items-center justify-between py-2">
        <button aria-label="Previous week" className="rounded-lg px-3 py-2 text-xl text-muted hover:bg-ink/5" onClick={() => go(prevWs)}>
          ‹
        </button>
        <h1 className="num text-xl font-bold">
          {ws === thisWeek ? 'This week' : `${shortDay(ws)} – ${shortDay(shiftIso(ws, 6))}`}
        </h1>
        <button
          aria-label="Next week"
          disabled={ws >= thisWeek}
          className="rounded-lg px-3 py-2 text-xl text-muted hover:bg-ink/5 disabled:opacity-30"
          onClick={() => go(shiftIso(ws, 7))}
        >
          ›
        </button>
      </header>
      <section className="mt-2 rounded-[28px] bg-surface p-5">
        {food.error ? <ErrorNote error={food.error} /> : week ? <WeekDetail week={week} /> : <Spinner />}
      </section>
    </main>
  )
}
