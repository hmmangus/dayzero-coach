import { z } from 'zod'
import {
  ClientSchema,
  ClientTargetsSchema,
  DailyMetricSchema,
  FoodEntrySchema,
  SavedFoodSchema,
  type NewClient,
  type TargetsInput,
} from '../schemas'
import { buildDemoDb, DEMO_COACH_EMAIL, type DemoDb } from './demoSeed'
import type { DailyMetricPatch, Repository, Viewer } from './repository'

const DB_KEY = 'dayzero.demo.db'
const VIEWER_KEY = 'dayzero.demo.viewer'

const DemoDbSchema = z.object({
  schemaVersion: z.literal(1),
  clients: z.array(ClientSchema),
  targets: z.array(ClientTargetsSchema),
  foods: z.array(FoodEntrySchema),
  savedFoods: z.array(SavedFoodSchema),
  metrics: z.array(DailyMetricSchema),
})

const uid = () =>
  typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID()
    : Math.random().toString(36).slice(2)

function safeGet(key: string): string | null {
  try {
    return localStorage.getItem(key)
  } catch {
    return null
  }
}
function safeSet(key: string, value: string | null) {
  try {
    if (value === null) localStorage.removeItem(key)
    else localStorage.setItem(key, value)
  } catch {
    /* storage unavailable (private mode) — keep working in memory */
  }
}

/**
 * Browser-only implementation for demos and local development.
 * Mirrors the Supabase rules loosely: a client viewer only ever asks for their own data.
 */
export class DemoRepository implements Repository {
  readonly mode = 'demo' as const
  private db: DemoDb
  private listeners = new Set<() => void>()

  constructor() {
    this.db = this.load()
  }

  private load(): DemoDb {
    const raw = safeGet(DB_KEY)
    if (raw) {
      try {
        const parsed = DemoDbSchema.safeParse(JSON.parse(raw))
        if (parsed.success) return parsed.data
      } catch {
        /* corrupted JSON falls through to a fresh seed */
      }
    }
    const fresh = buildDemoDb()
    safeSet(DB_KEY, JSON.stringify(fresh))
    return fresh
  }

  private save() {
    safeSet(DB_KEY, JSON.stringify(this.db))
  }

  resetDemoData() {
    this.db = buildDemoDb()
    this.save()
    this.listeners.forEach((l) => l())
  }

  // ---- auth ----
  async getViewer(): Promise<Viewer | null> {
    const email = safeGet(VIEWER_KEY)
    if (!email) return null
    return { userId: email, email, role: email === DEMO_COACH_EMAIL ? 'coach' : 'client' }
  }

  async signIn(email: string) {
    safeSet(VIEWER_KEY, email.trim().toLowerCase())
    this.listeners.forEach((l) => l())
    return { message: 'Signed in (demo).' }
  }

  async signOut() {
    safeSet(VIEWER_KEY, null)
    this.listeners.forEach((l) => l())
  }

  onAuthChange(cb: () => void) {
    this.listeners.add(cb)
    return () => {
      this.listeners.delete(cb)
    }
  }

  // ---- clients ----
  async getMyClient() {
    const viewer = await this.getViewer()
    if (!viewer) return null
    return this.db.clients.find((c) => c.email === viewer.email) ?? null
  }

  async listClients() {
    return [...this.db.clients].sort((a, b) => a.name.localeCompare(b.name))
  }

  async getClient(id: string) {
    return this.db.clients.find((c) => c.id === id) ?? null
  }

  async createClient(input: NewClient, targets: TargetsInput) {
    const client = ClientSchema.parse({
      ...input,
      email: input.email.toLowerCase(),
      id: uid(),
      profileId: null,
      createdAt: new Date().toISOString(),
    })
    this.db.clients.push(client)
    this.save()
    await this.setTargets(client.id, targets, input.startDate ?? new Date().toISOString().slice(0, 10))
    return client
  }

  async updateClient(id: string, patch: Partial<NewClient>) {
    const i = this.db.clients.findIndex((c) => c.id === id)
    if (i < 0) throw new Error('Client not found')
    this.db.clients[i] = ClientSchema.parse({ ...this.db.clients[i], ...patch })
    this.save()
    return this.db.clients[i]
  }

  // ---- targets ----
  async listTargets(clientId: string) {
    return this.db.targets
      .filter((t) => t.clientId === clientId)
      .sort((a, b) => a.effectiveFrom.localeCompare(b.effectiveFrom))
  }

  async setTargets(clientId: string, t: TargetsInput, effectiveFrom: string) {
    const existing = this.db.targets.find((x) => x.clientId === clientId && x.effectiveFrom === effectiveFrom)
    const row = ClientTargetsSchema.parse({ ...t, clientId, effectiveFrom, id: existing?.id ?? uid() })
    this.db.targets = this.db.targets.filter((x) => x !== existing).concat(row)
    this.save()
    return row
  }

  // ---- food ----
  async listFoodEntries(clientId: string, from: string, to: string) {
    return this.db.foods
      .filter((f) => f.clientId === clientId && f.date >= from && f.date <= to)
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt))
  }

  async addFoodEntry(e: Parameters<Repository['addFoodEntry']>[0]) {
    const row = FoodEntrySchema.parse({ ...e, id: uid(), createdAt: new Date().toISOString() })
    this.db.foods.push(row)
    this.save()
    return row
  }

  async deleteFoodEntry(id: string) {
    this.db.foods = this.db.foods.filter((f) => f.id !== id)
    this.save()
  }

  async listSavedFoods(clientId: string) {
    return this.db.savedFoods.filter((s) => s.clientId === clientId).sort((a, b) => a.name.localeCompare(b.name))
  }

  async saveFood(clientId: string, f: Parameters<Repository['saveFood']>[1]) {
    const row = SavedFoodSchema.parse({ ...f, clientId, id: uid() })
    this.db.savedFoods.push(row)
    this.save()
    return row
  }

  async deleteSavedFood(id: string) {
    this.db.savedFoods = this.db.savedFoods.filter((s) => s.id !== id)
    this.save()
  }

  // ---- weight / steps ----
  async listDailyMetrics(clientId: string, from: string, to: string) {
    return this.db.metrics
      .filter((m) => m.clientId === clientId && m.date >= from && m.date <= to)
      .sort((a, b) => a.date.localeCompare(b.date))
  }

  async upsertDailyMetric(clientId: string, date: string, patch: DailyMetricPatch) {
    const existing = this.db.metrics.find((m) => m.clientId === clientId && m.date === date)
    const row = DailyMetricSchema.parse({
      id: existing?.id ?? uid(),
      clientId,
      date,
      weightLbs: existing?.weightLbs ?? null,
      steps: existing?.steps ?? null,
      note: existing?.note ?? null,
      ...patch,
    })
    this.db.metrics = this.db.metrics.filter((m) => m !== existing).concat(row)
    this.save()
    return row
  }
}
